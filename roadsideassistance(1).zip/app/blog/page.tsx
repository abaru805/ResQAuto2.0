import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function BlogPage() {
  return (
    <div className="container py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">RoadRescue Blog</h1>
        <p className="mt-4 text-muted-foreground text-lg">
          Tips, advice, and stories from the road to keep you informed and prepared.
        </p>
      </div>

      <Tabs defaultValue="all" className="w-full mb-8">
        <div className="flex justify-center">
          <TabsList className="mb-8">
            <TabsTrigger value="all">All Posts</TabsTrigger>
            <TabsTrigger value="tips">Driving Tips</TabsTrigger>
            <TabsTrigger value="maintenance">Car Maintenance</TabsTrigger>
            <TabsTrigger value="safety">Road Safety</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="all" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <BlogCard
              title="10 Essential Items to Keep in Your Car for Emergencies"
              description="Being prepared can make all the difference when you're stranded. Here are the must-have items for your vehicle emergency kit."
              image="/placeholder.svg?height=200&width=300"
              date="March 15, 2023"
              category="Safety"
              slug="essential-items-car-emergency-kit"
            />
            <BlogCard
              title="How to Change a Flat Tire: A Step-by-Step Guide"
              description="Learn the proper technique for safely changing a flat tire on your own, even if you've never done it before."
              image="/placeholder.svg?height=200&width=300"
              date="April 22, 2023"
              category="Maintenance"
              slug="how-to-change-flat-tire"
            />
            <BlogCard
              title="Winter Driving Tips: Staying Safe on Icy Roads"
              description="Navigate winter conditions with confidence using these expert tips for driving on snow and ice."
              image="/placeholder.svg?height=200&width=300"
              date="November 10, 2023"
              category="Driving Tips"
              slug="winter-driving-tips"
            />
            <BlogCard
              title="Signs Your Car Battery is About to Die"
              description="Don't get caught with a dead battery. Learn to recognize these warning signs before you're stranded."
              image="/placeholder.svg?height=200&width=300"
              date="May 18, 2023"
              category="Maintenance"
              slug="signs-car-battery-dying"
            />
            <BlogCard
              title="What to Do If You're Locked Out of Your Car"
              description="Being locked out is frustrating, but there are steps you can take while waiting for professional help."
              image="/placeholder.svg?height=200&width=300"
              date="June 7, 2023"
              category="Tips"
              slug="locked-out-of-car"
            />
            <BlogCard
              title="The Ultimate Road Trip Checklist"
              description="Planning a long drive? Make sure your vehicle is ready with this comprehensive preparation guide."
              image="/placeholder.svg?height=200&width=300"
              date="July 14, 2023"
              category="Travel"
              slug="road-trip-checklist"
            />
          </div>
        </TabsContent>

        <TabsContent value="tips" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <BlogCard
              title="Winter Driving Tips: Staying Safe on Icy Roads"
              description="Navigate winter conditions with confidence using these expert tips for driving on snow and ice."
              image="/placeholder.svg?height=200&width=300"
              date="November 10, 2023"
              category="Driving Tips"
              slug="winter-driving-tips"
            />
            <BlogCard
              title="The Ultimate Road Trip Checklist"
              description="Planning a long drive? Make sure your vehicle is ready with this comprehensive preparation guide."
              image="/placeholder.svg?height=200&width=300"
              date="July 14, 2023"
              category="Travel"
              slug="road-trip-checklist"
            />
          </div>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <BlogCard
              title="How to Change a Flat Tire: A Step-by-Step Guide"
              description="Learn the proper technique for safely changing a flat tire on your own, even if you've never done it before."
              image="/placeholder.svg?height=200&width=300"
              date="April 22, 2023"
              category="Maintenance"
              slug="how-to-change-flat-tire"
            />
            <BlogCard
              title="Signs Your Car Battery is About to Die"
              description="Don't get caught with a dead battery. Learn to recognize these warning signs before you're stranded."
              image="/placeholder.svg?height=200&width=300"
              date="May 18, 2023"
              category="Maintenance"
              slug="signs-car-battery-dying"
            />
          </div>
        </TabsContent>

        <TabsContent value="safety" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <BlogCard
              title="10 Essential Items to Keep in Your Car for Emergencies"
              description="Being prepared can make all the difference when you're stranded. Here are the must-have items for your vehicle emergency kit."
              image="/placeholder.svg?height=200&width=300"
              date="March 15, 2023"
              category="Safety"
              slug="essential-items-car-emergency-kit"
            />
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-16 bg-muted rounded-lg p-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold tracking-tighter">Subscribe to Our Newsletter</h2>
          <p className="mt-4 text-muted-foreground">
            Get the latest roadside assistance tips, seasonal driving advice, and exclusive offers delivered to your
            inbox.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            />
            <Button>Subscribe</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

interface BlogCardProps {
  title: string
  description: string
  image: string
  date: string
  category: string
  slug: string
}

function BlogCard({ title, description, image, date, category, slug }: BlogCardProps) {
  return (
    <Card className="overflow-hidden flex flex-col h-full">
      <div className="relative h-48 w-full">
        <Image src={image || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <CardHeader>
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-medium px-2 py-1 bg-primary/10 text-primary rounded-full">{category}</span>
          <span className="text-xs text-muted-foreground">{date}</span>
        </div>
        <CardTitle className="line-clamp-2">{title}</CardTitle>
        <CardDescription className="line-clamp-3">{description}</CardDescription>
      </CardHeader>
      <CardFooter className="mt-auto">
        <Button asChild variant="outline" className="w-full">
          <Link href={`/blog/${slug}`}>
            Read More <ChevronRight className="ml-1 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

