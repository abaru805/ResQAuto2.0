import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function TestimonialsPage() {
  return (
    <div className="container py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Customer Testimonials</h1>
        <p className="mt-4 text-muted-foreground text-lg">
          Don't just take our word for it. See what our customers have to say about our services.
        </p>
      </div>

      <Tabs defaultValue="all" className="w-full mb-8">
        <div className="flex justify-center">
          <TabsList className="mb-8">
            <TabsTrigger value="all">All Reviews</TabsTrigger>
            <TabsTrigger value="5star">5 Star</TabsTrigger>
            <TabsTrigger value="4star">4 Star</TabsTrigger>
            <TabsTrigger value="3star">3 Star & Below</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="all" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <TestimonialCard
              name="Sarah Johnson"
              location="Los Angeles, CA"
              rating={5}
              quote="I was stranded on the highway with a flat tire. RoadRescue arrived within 15 minutes and got me back on the road quickly. Excellent service!"
              image="/placeholder.svg?height=100&width=100"
              date="March 15, 2023"
              service="Flat Tire Change"
            />
            <TestimonialCard
              name="Michael Chen"
              location="Seattle, WA"
              rating={5}
              quote="Their premium membership has saved me multiple times. The app makes it so easy to request help, and the technicians are always professional."
              image="/placeholder.svg?height=100&width=100"
              date="February 3, 2023"
              service="Battery Jump Start"
            />
            <TestimonialCard
              name="Jessica Martinez"
              location="Miami, FL"
              rating={4}
              quote="When my battery died in a parking garage, I thought I was stuck for hours. RoadRescue came to the rescue within 20 minutes. Great service!"
              image="/placeholder.svg?height=100&width=100"
              date="April 22, 2023"
              service="Battery Jump Start"
            />
            <TestimonialCard
              name="David Wilson"
              location="Chicago, IL"
              rating={5}
              quote="I locked my keys in my car at the grocery store. The technician arrived quickly and had my door open in minutes. Very impressed with the service!"
              image="/placeholder.svg?height=100&width=100"
              date="January 17, 2023"
              service="Lockout Assistance"
            />
            <TestimonialCard
              name="Emily Thompson"
              location="Denver, CO"
              rating={4}
              quote="My car needed to be towed after an accident. The driver was very professional and careful with my vehicle. Would recommend their towing service."
              image="/placeholder.svg?height=100&width=100"
              date="May 9, 2023"
              service="Towing Services"
            />
            <TestimonialCard
              name="Robert Garcia"
              location="Phoenix, AZ"
              rating={5}
              quote="I ran out of gas in the middle of nowhere. RoadRescue delivered fuel within 30 minutes. Saved my day!"
              image="/placeholder.svg?height=100&width=100"
              date="June 14, 2023"
              service="Fuel Delivery"
            />
            <TestimonialCard
              name="Amanda Lee"
              location="Portland, OR"
              rating={3}
              quote="Service was good but took longer than expected to arrive. The technician was professional and fixed my flat tire quickly once he arrived."
              image="/placeholder.svg?height=100&width=100"
              date="July 2, 2023"
              service="Flat Tire Change"
            />
            <TestimonialCard
              name="Thomas Brown"
              location="Austin, TX"
              rating={5}
              quote="My car got stuck in mud after heavy rain. The winching service was excellent and got me out without any damage to my vehicle."
              image="/placeholder.svg?height=100&width=100"
              date="August 11, 2023"
              service="Winching"
            />
            <TestimonialCard
              name="Olivia Wilson"
              location="Nashville, TN"
              rating={4}
              quote="I've been a member for 2 years and have used their services multiple times. Always reliable and professional."
              image="/placeholder.svg?height=100&width=100"
              date="September 5, 2023"
              service="Multiple Services"
            />
          </div>
        </TabsContent>

        <TabsContent value="5star" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <TestimonialCard
              name="Sarah Johnson"
              location="Los Angeles, CA"
              rating={5}
              quote="I was stranded on the highway with a flat tire. RoadRescue arrived within 15 minutes and got me back on the road quickly. Excellent service!"
              image="/placeholder.svg?height=100&width=100"
              date="March 15, 2023"
              service="Flat Tire Change"
            />
            <TestimonialCard
              name="Michael Chen"
              location="Seattle, WA"
              rating={5}
              quote="Their premium membership has saved me multiple times. The app makes it so easy to request help, and the technicians are always professional."
              image="/placeholder.svg?height=100&width=100"
              date="February 3, 2023"
              service="Battery Jump Start"
            />
            <TestimonialCard
              name="David Wilson"
              location="Chicago, IL"
              rating={5}
              quote="I locked my keys in my car at the grocery store. The technician arrived quickly and had my door open in minutes. Very impressed with the service!"
              image="/placeholder.svg?height=100&width=100"
              date="January 17, 2023"
              service="Lockout Assistance"
            />
            <TestimonialCard
              name="Robert Garcia"
              location="Phoenix, AZ"
              rating={5}
              quote="I ran out of gas in the middle of nowhere. RoadRescue delivered fuel within 30 minutes. Saved my day!"
              image="/placeholder.svg?height=100&width=100"
              date="June 14, 2023"
              service="Fuel Delivery"
            />
            <TestimonialCard
              name="Thomas Brown"
              location="Austin, TX"
              rating={5}
              quote="My car got stuck in mud after heavy rain. The winching service was excellent and got me out without any damage to my vehicle."
              image="/placeholder.svg?height=100&width=100"
              date="August 11, 2023"
              service="Winching"
            />
          </div>
        </TabsContent>

        <TabsContent value="4star" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <TestimonialCard
              name="Jessica Martinez"
              location="Miami, FL"
              rating={4}
              quote="When my battery died in a parking garage, I thought I was stuck for hours. RoadRescue came to the rescue within 20 minutes. Great service!"
              image="/placeholder.svg?height=100&width=100"
              date="April 22, 2023"
              service="Battery Jump Start"
            />
            <TestimonialCard
              name="Emily Thompson"
              location="Denver, CO"
              rating={4}
              quote="My car needed to be towed after an accident. The driver was very professional and careful with my vehicle. Would recommend their towing service."
              image="/placeholder.svg?height=100&width=100"
              date="May 9, 2023"
              service="Towing Services"
            />
            <TestimonialCard
              name="Olivia Wilson"
              location="Nashville, TN"
              rating={4}
              quote="I've been a member for 2 years and have used their services multiple times. Always reliable and professional."
              image="/placeholder.svg?height=100&width=100"
              date="September 5, 2023"
              service="Multiple Services"
            />
          </div>
        </TabsContent>

        <TabsContent value="3star" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <TestimonialCard
              name="Amanda Lee"
              location="Portland, OR"
              rating={3}
              quote="Service was good but took longer than expected to arrive. The technician was professional and fixed my flat tire quickly once he arrived."
              image="/placeholder.svg?height=100&width=100"
              date="July 2, 2023"
              service="Flat Tire Change"
            />
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-16 bg-muted rounded-lg p-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold tracking-tighter">Share Your Experience</h2>
          <p className="mt-4 text-muted-foreground">
            We value your feedback! If you've used our services, please take a moment to share your experience.
          </p>
          <Button asChild className="mt-6">
            <Link href="/feedback">Submit a Review</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

interface TestimonialCardProps {
  name: string
  location: string
  rating: number
  quote: string
  image: string
  date: string
  service: string
}

function TestimonialCard({ name, location, rating, quote, image, date, service }: TestimonialCardProps) {
  return (
    <Card className="h-full flex flex-col">
      <CardContent className="pt-6 flex-grow">
        <div className="flex mb-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              className={`h-4 w-4 ${i < rating ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`}
            />
          ))}
        </div>
        <p className="italic text-muted-foreground">"{quote}"</p>
        <div className="mt-4 text-sm text-muted-foreground">
          <p>Service: {service}</p>
          <p>Date: {date}</p>
        </div>
      </CardContent>
      <CardFooter className="border-t pt-4 flex items-center">
        <Image src={image || "/placeholder.svg"} alt={name} width={40} height={40} className="rounded-full mr-3" />
        <div>
          <p className="font-medium text-sm">{name}</p>
          <p className="text-xs text-muted-foreground">{location}</p>
        </div>
      </CardFooter>
    </Card>
  )
}

