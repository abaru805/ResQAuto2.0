import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ChevronRight, MapPin, Shield, Truck, Wrench } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

// This is a mock function to get service data
// In a real app, this would fetch from a database or API
function getServiceData(slug: string) {
  const services = {
    "flat-tire": {
      title: "Flat Tire Change",
      description: "Quick replacement with your spare tire to get you back on the road.",
      longDescription:
        "Our flat tire change service provides quick and efficient replacement of your flat tire with your spare. Our trained technicians will safely jack up your vehicle, remove the flat tire, install your spare tire, and ensure it's properly secured. We'll also provide recommendations for permanent tire repair or replacement options.",
      icon: <Wrench className="w-10 h-10" />,
      image: "/placeholder.svg?height=400&width=600",
      benefits: [
        "Fast response times - average of 30 minutes",
        "Professional technicians with proper equipment",
        "Available 24/7 for emergency situations",
        "No additional fees for nights or weekends",
        "Service available roadside or at your home",
      ],
      pricing: {
        nonMember: "$75",
        basic: "Included (up to 4 per year)",
        premium: "Included (up to 6 per year)",
        family: "Included (up to 8 per year)",
      },
    },
    "battery-jumpstart": {
      title: "Battery Jump Start",
      description: "Revive your dead battery and diagnose potential issues.",
      longDescription:
        "Our battery jump start service helps you when your vehicle won't start due to a dead or weak battery. Our technicians will arrive with professional equipment to safely jump-start your vehicle. We'll also perform a basic diagnostic check to identify potential issues with your battery or charging system and provide recommendations for battery replacement if necessary.",
      icon: <Truck className="w-10 h-10" />,
      image: "/placeholder.svg?height=400&width=600",
      benefits: [
        "Professional-grade jump starter equipment",
        "Battery system diagnostic check included",
        "Available 24/7 for emergency situations",
        "Technicians trained in proper jump-start procedures",
        "Advice on battery replacement options",
      ],
      pricing: {
        nonMember: "$65",
        basic: "Included (up to 4 per year)",
        premium: "Included (up to 6 per year)",
        family: "Included (up to 8 per year)",
      },
    },
    "fuel-delivery": {
      title: "Fuel Delivery",
      description: "Emergency fuel delivered to your location when you run out.",
      longDescription:
        "Our fuel delivery service brings emergency fuel directly to your location when you run out. We'll provide enough fuel to get you to the nearest gas station. Our technicians will deliver the fuel and assist with adding it to your vehicle safely. This service is available 24/7 for emergency situations.",
      icon: <MapPin className="w-10 h-10" />,
      image: "/placeholder.svg?height=400&width=600",
      benefits: [
        "Fast delivery of emergency fuel",
        "Available for gasoline and diesel vehicles",
        "Enough fuel to reach the nearest gas station",
        "Available 24/7 for emergency situations",
        "Professional handling of fuel for safety",
      ],
      pricing: {
        nonMember: "$75 + fuel cost",
        basic: "Service included, fuel cost extra",
        premium: "Fully included (fuel cost covered)",
        family: "Fully included (fuel cost covered)",
      },
    },
    lockout: {
      title: "Lockout Assistance",
      description: "Professional assistance when you're locked out of your vehicle.",
      longDescription:
        "Our lockout assistance service helps you regain access to your vehicle when you're locked out. Our trained technicians use specialized tools to safely unlock your vehicle without causing damage. We can handle most makes and models of cars, trucks, and SUVs.",
      icon: <Shield className="w-10 h-10" />,
      image: "/placeholder.svg?height=400&width=600",
      benefits: [
        "Non-destructive entry techniques",
        "Specialized tools for various vehicle types",
        "Trained technicians with experience in vehicle entry",
        "Available 24/7 for emergency situations",
        "Service available roadside or at your home",
      ],
      pricing: {
        nonMember: "$85",
        basic: "Included (up to 4 per year)",
        premium: "Included (up to 6 per year)",
        family: "Included (up to 8 per year)",
      },
    },
    towing: {
      title: "Towing Services",
      description: "Safe transportation for your vehicle to a repair facility.",
      longDescription:
        "Our towing service provides safe transportation for your vehicle when it breaks down or is involved in an accident. We use modern tow trucks and equipment to ensure your vehicle is transported safely to your preferred repair facility or another location of your choice.",
      icon: <Truck className="w-10 h-10" />,
      image: "/placeholder.svg?height=400&width=600",
      benefits: [
        "Modern fleet of tow trucks",
        "Trained operators with proper certifications",
        "Careful handling of your vehicle",
        "Available 24/7 for emergency situations",
        "Transport to your preferred repair facility",
      ],
      pricing: {
        nonMember: "$100 + $4/mile",
        basic: "Included up to 5 miles, then $4/mile",
        premium: "Included up to 25 miles, then $3/mile",
        family: "Included up to 50 miles, then $2/mile",
      },
    },
    winching: {
      title: "Winching",
      description: "Recovery service to pull your vehicle from mud, snow, or other difficult terrain.",
      longDescription:
        "Our winching service helps recover your vehicle when it's stuck in mud, snow, sand, or other difficult terrain. Our technicians use powerful winches and proper techniques to safely extract your vehicle without causing damage. This service is especially valuable during adverse weather conditions or off-road situations.",
      icon: <Truck className="w-10 h-10" />,
      image: "/placeholder.svg?height=400&width=600",
      benefits: [
        "Powerful winching equipment",
        "Trained technicians in recovery techniques",
        "Safe extraction to minimize vehicle damage",
        "Available for various terrains and situations",
        "Available 24/7 for emergency situations",
      ],
      pricing: {
        nonMember: "$150",
        basic: "Not included",
        premium: "Included up to 100 feet",
        family: "Fully included (unlimited)",
      },
    },
  }

  return (
    services[slug as keyof typeof services] || {
      title: "Service Not Found",
      description: "The requested service information could not be found.",
      longDescription: "Please check the URL or return to our services page to find the service you're looking for.",
      icon: <Shield className="w-10 h-10" />,
      image: "/placeholder.svg?height=400&width=600",
      benefits: [],
      pricing: {
        nonMember: "N/A",
        basic: "N/A",
        premium: "N/A",
        family: "N/A",
      },
    }
  )
}

export default function ServiceDetailPage({ params }: { params: { slug: string } }) {
  const service = getServiceData(params.slug)

  return (
    <div className="container py-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div>
            <h1 className="text-4xl font-bold tracking-tighter">{service.title}</h1>
            <p className="mt-4 text-xl text-muted-foreground">{service.description}</p>
          </div>

          <div className="aspect-video relative rounded-lg overflow-hidden">
            <Image src={service.image || "/placeholder.svg"} alt={service.title} fill className="object-cover" />
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Service Details</h2>
            <p className="text-muted-foreground">{service.longDescription}</p>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Benefits</h2>
            <ul className="space-y-2">
              {service.benefits.map((benefit, index) => (
                <li key={index} className="flex items-start">
                  <ChevronRight className="h-5 w-5 text-primary shrink-0 mr-2" />
                  <span>{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-4">Pricing</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="p-4">
                <h3 className="font-bold">Non-Member Price</h3>
                <p className="text-2xl font-bold text-primary mt-2">{service.pricing.nonMember}</p>
                <p className="text-sm text-muted-foreground mt-1">One-time service fee</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-bold">Basic Membership</h3>
                <p className="text-lg font-medium mt-2">{service.pricing.basic}</p>
                <p className="text-sm text-muted-foreground mt-1">$9.99/month</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-bold">Premium Membership</h3>
                <p className="text-lg font-medium mt-2">{service.pricing.premium}</p>
                <p className="text-sm text-muted-foreground mt-1">$19.99/month</p>
              </Card>
              <Card className="p-4">
                <h3 className="font-bold">Family Membership</h3>
                <p className="text-lg font-medium mt-2">{service.pricing.family}</p>
                <p className="text-sm text-muted-foreground mt-1">$29.99/month</p>
              </Card>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-bold mb-4">Book This Service</h2>
            <p className="text-muted-foreground mb-6">
              Need {service.title.toLowerCase()}? Book now and we'll be there to help you as quickly as possible.
            </p>
            <Button asChild className="w-full">
              <Link href={`/services/book?service=${encodeURIComponent(service.title)}`}>Book Now</Link>
            </Button>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-bold mb-4">Emergency Assistance</h2>
            <p className="text-muted-foreground mb-6">
              Need immediate help? Request emergency assistance and we'll dispatch a technician right away.
            </p>
            <Button asChild variant="destructive" className="w-full">
              <Link href="/emergency">Request Emergency Service</Link>
            </Button>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-bold mb-4">Save With a Membership</h2>
            <p className="text-muted-foreground mb-6">
              Get this service included with our membership plans, plus many other benefits.
            </p>
            <Button asChild variant="outline" className="w-full">
              <Link href="/membership">View Membership Plans</Link>
            </Button>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-bold mb-4">Have Questions?</h2>
            <p className="text-muted-foreground mb-6">
              Our customer service team is available 24/7 to answer any questions you may have.
            </p>
            <Button asChild variant="outline" className="w-full">
              <Link href="/contact">Contact Us</Link>
            </Button>
          </Card>
        </div>
      </div>
    </div>
  )
}

