import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Battery, Car, Fuel, Key, MapPin, Wrench } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function ServicesPage() {
  return (
    <div className="container py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Our Services</h1>
        <p className="mt-4 text-muted-foreground text-lg">
          We offer a complete range of roadside assistance services to get you back on the road quickly and safely.
        </p>
      </div>

      <Tabs defaultValue="all" className="w-full mb-8">
        <div className="flex justify-center">
          <TabsList className="mb-8">
            <TabsTrigger value="all">All Services</TabsTrigger>
            <TabsTrigger value="tire">Tire Services</TabsTrigger>
            <TabsTrigger value="battery">Battery Services</TabsTrigger>
            <TabsTrigger value="fuel">Fuel Services</TabsTrigger>
            <TabsTrigger value="towing">Towing Services</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="all" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ServiceCard
              icon={<Wrench className="h-10 w-10" />}
              title="Flat Tire Change"
              description="Quick replacement with your spare tire to get you back on the road."
              link="/services/flat-tire"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Battery className="h-10 w-10" />}
              title="Battery Jump Start"
              description="Revive your dead battery and diagnose potential issues."
              link="/services/battery-jumpstart"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Fuel className="h-10 w-10" />}
              title="Fuel Delivery"
              description="Emergency fuel delivered to your location when you run out."
              link="/services/fuel-delivery"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Key className="h-10 w-10" />}
              title="Lockout Assistance"
              description="Professional assistance when you're locked out of your vehicle."
              link="/services/lockout"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Car className="h-10 w-10" />}
              title="Towing Services"
              description="Safe transportation for your vehicle to a repair facility."
              link="/services/towing"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<MapPin className="h-10 w-10" />}
              title="Winching"
              description="Recovery service to pull your vehicle from mud, snow, or other difficult terrain."
              link="/services/winching"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
          </div>
        </TabsContent>

        <TabsContent value="tire" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ServiceCard
              icon={<Wrench className="h-10 w-10" />}
              title="Flat Tire Change"
              description="Quick replacement with your spare tire to get you back on the road."
              link="/services/flat-tire"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Wrench className="h-10 w-10" />}
              title="Tire Repair"
              description="On-the-spot repair for minor tire damage when possible."
              link="/services/tire-repair"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Wrench className="h-10 w-10" />}
              title="Tire Pressure Check"
              description="Proper inflation to ensure safety and optimal fuel efficiency."
              link="/services/tire-pressure"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
          </div>
        </TabsContent>

        <TabsContent value="battery" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ServiceCard
              icon={<Battery className="h-10 w-10" />}
              title="Battery Jump Start"
              description="Revive your dead battery and diagnose potential issues."
              link="/services/battery-jumpstart"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Battery className="h-10 w-10" />}
              title="Battery Testing"
              description="Comprehensive testing to determine your battery's health and remaining life."
              link="/services/battery-testing"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Battery className="h-10 w-10" />}
              title="Battery Replacement"
              description="On-site battery replacement with quality batteries at competitive prices."
              link="/services/battery-replacement"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
          </div>
        </TabsContent>

        <TabsContent value="fuel" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ServiceCard
              icon={<Fuel className="h-10 w-10" />}
              title="Fuel Delivery"
              description="Emergency fuel delivered to your location when you run out."
              link="/services/fuel-delivery"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Fuel className="h-10 w-10" />}
              title="Wrong Fuel Assistance"
              description="Help when you've accidentally filled up with the wrong type of fuel."
              link="/services/wrong-fuel"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
          </div>
        </TabsContent>

        <TabsContent value="towing" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ServiceCard
              icon={<Car className="h-10 w-10" />}
              title="Towing Services"
              description="Safe transportation for your vehicle to a repair facility."
              link="/services/towing"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<MapPin className="h-10 w-10" />}
              title="Winching"
              description="Recovery service to pull your vehicle from mud, snow, or other difficult terrain."
              link="/services/winching"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
            <ServiceCard
              icon={<Car className="h-10 w-10" />}
              title="Motorcycle Towing"
              description="Specialized towing for motorcycles to ensure safe transport."
              link="/services/motorcycle-towing"
              imageUrl="/placeholder.svg?height=200&width=300"
            />
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-16 bg-muted rounded-lg p-8">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tighter">Need Emergency Assistance?</h2>
            <p className="mt-4 text-muted-foreground">
              Don't wait! Our emergency roadside assistance is available 24/7. Request help immediately and we'll be on
              our way.
            </p>
            <Button asChild className="mt-6 bg-destructive hover:bg-destructive/90">
              <Link href="/emergency">Request Emergency Assistance</Link>
            </Button>
          </div>
          <div className="hidden md:block">
            <Image
              src="/placeholder.svg?height=300&width=400"
              alt="Emergency Roadside Assistance"
              width={400}
              height={300}
              className="rounded-lg"
            />
          </div>
        </div>
      </div>

      <div className="mt-16">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl font-bold tracking-tighter">Frequently Asked Questions</h2>
          <p className="mt-4 text-muted-foreground">
            Find answers to common questions about our roadside assistance services.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">How quickly can I expect help to arrive?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                Our average response time is 15-30 minutes, depending on your location and current demand. Members
                receive priority service during high-volume periods.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">What areas do you service?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                We provide coverage throughout all 50 states and Canada. Our network includes over 45,000 service
                providers nationwide to ensure you're always covered.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Do I need to be a member to request service?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                No, we provide services to both members and non-members. However, members enjoy priority service,
                discounted rates, and additional benefits not available to non-members.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">What payment methods do you accept?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                We accept all major credit cards, debit cards, and digital payment methods including Apple Pay and
                Google Pay. Members can also use their membership benefits without upfront payment.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8">
          <Button asChild variant="outline">
            <Link href="/faqs">View All FAQs</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

interface ServiceCardProps {
  icon: React.ReactNode
  title: string
  description: string
  link: string
  imageUrl: string
}

function ServiceCard({ icon, title, description, link, imageUrl }: ServiceCardProps) {
  return (
    <Card className="overflow-hidden flex flex-col h-full">
      <div className="relative h-48 w-full">
        <Image src={imageUrl || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <CardHeader>
        <div className="p-2 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4">
          {icon}
        </div>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardFooter className="mt-auto">
        <Button asChild>
          <Link href={link}>Learn More</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

