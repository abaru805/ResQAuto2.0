"use client"

import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { AlertTriangle } from "lucide-react"

export default function ErrorPage() {
  const searchParams = useSearchParams()
  const error = searchParams.get("error")

  let errorTitle = "An error occurred"
  let errorMessage = "Something went wrong. Please try again later."

  // Handle specific error types
  switch (error) {
    case "Configuration":
      errorTitle = "Server configuration error"
      errorMessage = "There is a problem with the server configuration. Please contact support."
      break
    case "AccessDenied":
      errorTitle = "Access denied"
      errorMessage = "You do not have permission to sign in."
      break
    case "Verification":
      errorTitle = "Verification error"
      errorMessage = "The verification link may have been used or is invalid."
      break
    case "OAuthSignin":
    case "OAuthCallback":
    case "OAuthCreateAccount":
    case "EmailCreateAccount":
    case "Callback":
    case "OAuthAccountNotLinked":
    case "EmailSignin":
    case "CredentialsSignin":
      errorTitle = "Authentication error"
      errorMessage = "There was a problem with authentication. Please try again."
      break
    default:
      // Use default error message
      break
  }

  return (
    <div className="container flex items-center justify-center min-h-[calc(100vh-13rem)] py-8">
      <Card className="mx-auto max-w-md w-full">
        <CardHeader className="text-center">
          <div className="mx-auto bg-red-100 dark:bg-red-900 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4">
            <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-400" />
          </div>
          <CardTitle className="text-2xl font-bold">{errorTitle}</CardTitle>
          <CardDescription>{errorMessage}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center text-sm text-muted-foreground">Error code: {error || "Unknown"}</p>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button asChild>
            <Link href="/">Return to Home</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

