import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChevronRight, MapPin } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function CareersPage() {
  return (
    <div className="container py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Join Our Team</h1>
        <p className="mt-4 text-muted-foreground text-lg">
          Build your career with RoadRescue and help us deliver exceptional roadside assistance to drivers in need.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 items-center mb-16">
        <div>
          <h2 className="text-3xl font-bold tracking-tighter mb-4">Why Work With Us?</h2>
          <p className="text-muted-foreground mb-6">
            At RoadRescue, we're committed to creating a positive work environment where employees can thrive and grow.
            We offer competitive benefits, opportunities for advancement, and the chance to make a real difference in
            people's lives every day.
          </p>
          <ul className="space-y-2">
            <li className="flex items-start">
              <div className="mr-2 mt-1 h-5 w-5 text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M20 6L9 17l-5-5" />
                </svg>
              </div>
              <span>Competitive salary and benefits package</span>
            </li>
            <li className="flex items-start">
              <div className="mr-2 mt-1 h-5 w-5 text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M20 6L9 17l-5-5" />
                </svg>
              </div>
              <span>Ongoing training and professional development</span>
            </li>
            <li className="flex items-start">
              <div className="mr-2 mt-1 h-5 w-5 text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M20 6L9 17l-5-5" />
                </svg>
              </div>
              <span>Flexible scheduling options</span>
            </li>
            <li className="flex items-start">
              <div className="mr-2 mt-1 h-5 w-5 text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M20 6L9 17l-5-5" />
                </svg>
              </div>
              <span>Career advancement opportunities</span>
            </li>
            <li className="flex items-start">
              <div className="mr-2 mt-1 h-5 w-5 text-primary">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M20 6L9 17l-5-5" />
                </svg>
              </div>
              <span>Positive and supportive work environment</span>
            </li>
          </ul>
        </div>
        <div className="hidden md:block">
          <Image
            src="/placeholder.svg?height=400&width=500"
            alt="RoadRescue Team"
            width={500}
            height={400}
            className="rounded-lg"
          />
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full mb-8">
        <div className="flex justify-center">
          <TabsList className="mb-8">
            <TabsTrigger value="all">All Positions</TabsTrigger>
            <TabsTrigger value="field">Field Operations</TabsTrigger>
            <TabsTrigger value="customer">Customer Service</TabsTrigger>
            <TabsTrigger value="tech">Technology</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="all" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <JobCard
              title="Roadside Technician"
              location="Multiple Locations"
              type="Full-time"
              description="Provide on-site assistance to stranded motorists, including tire changes, jump starts, and minor repairs."
              department="Field Operations"
              id="RST-2023-01"
            />
            <JobCard
              title="Customer Service Representative"
              location="Austin, TX"
              type="Full-time / Part-time"
              description="Handle incoming assistance calls, dispatch technicians, and ensure customer satisfaction throughout the service process."
              department="Customer Service"
              id="CSR-2023-02"
            />
            <JobCard
              title="Mobile App Developer"
              location="Remote"
              type="Full-time"
              description="Join our technology team to enhance and maintain our customer-facing mobile applications for iOS and Android."
              department="Technology"
              id="DEV-2023-03"
            />
            <JobCard
              title="Tow Truck Operator"
              location="Multiple Locations"
              type="Full-time"
              description="Operate tow trucks to safely transport vehicles to repair facilities or customer-specified locations."
              department="Field Operations"
              id="TTO-2023-04"
            />
            <JobCard
              title="Dispatch Supervisor"
              location="Phoenix, AZ"
              type="Full-time"
              description="Oversee the dispatch team, optimize response times, and ensure efficient allocation of resources during peak periods."
              department="Operations"
              id="DS-2023-05"
            />
            <JobCard
              title="Marketing Specialist"
              location="Austin, TX"
              type="Full-time"
              description="Develop and implement marketing strategies to increase brand awareness and membership sign-ups."
              department="Marketing"
              id="MKT-2023-06"
            />
          </div>
        </TabsContent>

        <TabsContent value="field" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <JobCard
              title="Roadside Technician"
              location="Multiple Locations"
              type="Full-time"
              description="Provide on-site assistance to stranded motorists, including tire changes, jump starts, and minor repairs."
              department="Field Operations"
              id="RST-2023-01"
            />
            <JobCard
              title="Tow Truck Operator"
              location="Multiple Locations"
              type="Full-time"
              description="Operate tow trucks to safely transport vehicles to repair facilities or customer-specified locations."
              department="Field Operations"
              id="TTO-2023-04"
            />
          </div>
        </TabsContent>

        <TabsContent value="customer" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <JobCard
              title="Customer Service Representative"
              location="Austin, TX"
              type="Full-time / Part-time"
              description="Handle incoming assistance calls, dispatch technicians, and ensure customer satisfaction throughout the service process."
              department="Customer Service"
              id="CSR-2023-02"
            />
            <JobCard
              title="Dispatch Supervisor"
              location="Phoenix, AZ"
              type="Full-time"
              description="Oversee the dispatch team, optimize response times, and ensure efficient allocation of resources during peak periods."
              department="Operations"
              id="DS-2023-05"
            />
          </div>
        </TabsContent>

        <TabsContent value="tech" className="space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <JobCard
              title="Mobile App Developer"
              location="Remote"
              type="Full-time"
              description="Join our technology team to enhance and maintain our customer-facing mobile applications for iOS and Android."
              department="Technology"
              id="DEV-2023-03"
            />
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-16 bg-muted rounded-lg p-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold tracking-tighter">Don't See the Right Fit?</h2>
          <p className="mt-4 text-muted-foreground">
            We're always looking for talented individuals to join our team. Send us your resume and we'll keep it on
            file for future opportunities.
          </p>
          <Button asChild className="mt-6">
            <Link href="/careers/apply">Submit Your Resume</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

interface JobCardProps {
  title: string
  location: string
  type: string
  description: string
  department: string
  id: string
}

function JobCard({ title, location, type, description, department, id }: JobCardProps) {
  return (
    <Card className="flex flex-col h-full">
      <CardHeader>
        <div className="flex items-center mb-2">
          <span className="text-xs font-medium px-2 py-1 bg-primary/10 text-primary rounded-full">{department}</span>
        </div>
        <CardTitle>{title}</CardTitle>
        <CardDescription className="flex items-center mt-2">
          <MapPin className="h-4 w-4 mr-1" /> {location} • {type}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-muted-foreground">{description}</p>
        <p className="text-sm text-muted-foreground mt-4">Job ID: {id}</p>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full">
          <Link href={`/careers/${id}`}>
            View Details <ChevronRight className="ml-1 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

