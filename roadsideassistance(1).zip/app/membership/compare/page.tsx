import { Button } from "@/components/ui/button"
import { Check, X } from "lucide-react"
import Link from "next/link"

export default function MembershipComparePage() {
  return (
    <div className="container py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Membership Plan Comparison</h1>
        <p className="mt-4 text-muted-foreground text-lg">
          Compare our membership plans side by side to find the perfect fit for your needs.
        </p>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              <th className="text-left p-4 border-b"></th>
              <th className="p-4 border-b text-center">
                <div className="text-xl font-bold">Basic</div>
                <div className="text-2xl font-bold mt-2">$9.99</div>
                <div className="text-sm text-muted-foreground">per month</div>
                <div className="mt-4">
                  <Button asChild size="sm">
                    <Link href="/membership/basic">Select Plan</Link>
                  </Button>
                </div>
              </th>
              <th className="p-4 border-b text-center bg-primary/5 relative">
                <div className="absolute top-0 left-0 right-0 -translate-y-full bg-primary text-primary-foreground text-center text-sm py-1">
                  Most Popular
                </div>
                <div className="text-xl font-bold">Premium</div>
                <div className="text-2xl font-bold mt-2">$19.99</div>
                <div className="text-sm text-muted-foreground">per month</div>
                <div className="mt-4">
                  <Button asChild size="sm" className="bg-primary">
                    <Link href="/membership/premium">Select Plan</Link>
                  </Button>
                </div>
              </th>
              <th className="p-4 border-b text-center">
                <div className="text-xl font-bold">Family</div>
                <div className="text-2xl font-bold mt-2">$29.99</div>
                <div className="text-sm text-muted-foreground">per month</div>
                <div className="mt-4">
                  <Button asChild size="sm">
                    <Link href="/membership/family">Select Plan</Link>
                  </Button>
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="p-4 border-b font-medium">24/7 Roadside Assistance</td>
              <td className="p-4 border-b text-center">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
              <td className="p-4 border-b text-center">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Flat Tire Assistance</td>
              <td className="p-4 border-b text-center">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
              <td className="p-4 border-b text-center">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Battery Jump Start</td>
              <td className="p-4 border-b text-center">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
              <td className="p-4 border-b text-center">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Lockout Service</td>
              <td className="p-4 border-b text-center">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
              <td className="p-4 border-b text-center">
                <Check className="mx-auto h-5 w-5 text-primary" />
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Towing Service</td>
              <td className="p-4 border-b text-center">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Up to 5 miles</div>
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Up to 25 miles</div>
              </td>
              <td className="p-4 border-b text-center">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Up to 50 miles</div>
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Fuel Delivery</td>
              <td className="p-4 border-b text-center">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Service only (fuel cost extra)</div>
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Includes fuel cost</div>
              </td>
              <td className="p-4 border-b text-center">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Includes fuel cost</div>
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Winching</td>
              <td className="p-4 border-b text-center">
                <X className="mx-auto h-5 w-5 text-muted-foreground" />
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Up to 100 feet</div>
              </td>
              <td className="p-4 border-b text-center">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Unlimited</div>
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Rental Car Benefits</td>
              <td className="p-4 border-b text-center">
                <X className="mx-auto h-5 w-5 text-muted-foreground" />
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Up to $50/day, 2 days max</div>
              </td>
              <td className="p-4 border-b text-center">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Up to $75/day, 3 days max</div>
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Trip Interruption</td>
              <td className="p-4 border-b text-center">
                <X className="mx-auto h-5 w-5 text-muted-foreground" />
              </td>
              <td className="p-4 border-b text-center bg-primary/5">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Up to $250</div>
              </td>
              <td className="p-4 border-b text-center">
                <div>
                  <Check className="mx-auto h-5 w-5 text-primary" />
                </div>
                <div className="text-xs text-muted-foreground mt-1">Up to $500</div>
              </td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Number of Vehicles</td>
              <td className="p-4 border-b text-center">1</td>
              <td className="p-4 border-b text-center bg-primary/5">1</td>
              <td className="p-4 border-b text-center">Up to 4</td>
            </tr>
            <tr>
              <td className="p-4 border-b font-medium">Service Calls per Year</td>
              <td className="p-4 border-b text-center">4</td>
              <td className="p-4 border-b text-center bg-primary/5">6</td>
              <td className="p-4 border-b text-center">8</td>
            </tr>
            <tr>
              <td className="p-4"></td>
              <td className="p-4 text-center">
                <Button asChild>
                  <Link href="/membership/basic">Select Basic</Link>
                </Button>
              </td>
              <td className="p-4 text-center bg-primary/5">
                <Button asChild className="bg-primary">
                  <Link href="/membership/premium">Select Premium</Link>
                </Button>
              </td>
              <td className="p-4 text-center">
                <Button asChild>
                  <Link href="/membership/family">Select Family</Link>
                </Button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}

