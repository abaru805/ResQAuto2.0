import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check, ChevronRight, X } from "lucide-react"
import Link from "next/link"
// import { formatPrice } from "@/lib/utils"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Format price locally instead of importing
function formatPrice(
  price: number,
  options: {
    currency?: "USD" | "EUR" | "GBP" | "BDT"
    notation?: Intl.NumberFormatOptions["notation"]
  } = {},
) {
  const { currency = "USD", notation = "compact" } = options

  const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    notation,
    maximumFractionDigits: 2,
  })

  return formatter.format(price)
}

const plans = [
  {
    id: "basic",
    title: "Basic",
    description: "Essential coverage for occasional drivers",
    priceMonthly: 9.99,
    priceYearly: 99.99,
    features: [
      { name: "24/7 Roadside Assistance", included: true },
      { name: "Flat Tire Assistance", included: true },
      { name: "Flat Tire Assistance", included: true },
      { name: "Battery Jump Start", included: true },
      { name: "Lockout Service", included: true },
      { name: "Towing Service", included: true, details: "Up to 5 miles" },
      { name: "Fuel Delivery", included: true, details: "Service only (fuel cost extra)" },
      { name: "Winching", included: false },
      { name: "Rental Car Benefits", included: false },
      { name: "Trip Interruption", included: false },
    ],
    highlighted: false,
  },
  {
    id: "premium",
    title: "Premium",
    description: "Comprehensive coverage for regular drivers",
    priceMonthly: 19.99,
    priceYearly: 199.99,
    features: [
      { name: "24/7 Roadside Assistance", included: true },
      { name: "Flat Tire Assistance", included: true },
      { name: "Battery Jump Start", included: true },
      { name: "Lockout Service", included: true },
      { name: "Towing Service", included: true, details: "Up to 25 miles" },
      { name: "Fuel Delivery", included: true, details: "Includes fuel cost" },
      { name: "Winching", included: true, details: "Up to 100 feet" },
      { name: "Rental Car Benefits", included: true, details: "Up to $50/day, 2 days max" },
      { name: "Trip Interruption", included: true, details: "Up to $250" },
    ],
    highlighted: true,
  },
  {
    id: "family",
    title: "Family",
    description: "Complete protection for multiple vehicles",
    priceMonthly: 29.99,
    priceYearly: 299.99,
    features: [
      { name: "24/7 Roadside Assistance", included: true },
      { name: "Flat Tire Assistance", included: true },
      { name: "Battery Jump Start", included: true },
      { name: "Lockout Service", included: true },
      { name: "Towing Service", included: true, details: "Up to 50 miles" },
      { name: "Fuel Delivery", included: true, details: "Includes fuel cost" },
      { name: "Winching", included: true, details: "Unlimited" },
      { name: "Rental Car Benefits", included: true, details: "Up to $75/day, 3 days max" },
      { name: "Trip Interruption", included: true, details: "Up to $500" },
    ],
    highlighted: false,
    extraDetail: "Covers up to 4 vehicles",
  },
]

export default function MembershipPage() {
  return (
    <div className="container py-12">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Membership Plans</h1>
        <p className="mt-4 text-muted-foreground text-lg">
          Choose a membership plan that fits your needs and enjoy exclusive benefits and priority service.
        </p>
      </div>

      <Tabs defaultValue="monthly" className="w-full mb-8">
        <div className="flex justify-center">
          <TabsList>
            <TabsTrigger value="monthly">Monthly Billing</TabsTrigger>
            <TabsTrigger value="yearly">Annual Billing (Save 15%)</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="monthly" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <Card
                key={plan.id}
                className={`flex flex-col ${plan.highlighted ? "border-primary shadow-lg relative" : ""}`}
              >
                {plan.highlighted && (
                  <div className="py-1 px-4 bg-primary text-primary-foreground text-center text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <CardHeader>
                  <CardTitle>{plan.title}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-bold">
                      {formatPrice(plan.priceMonthly, { notation: "standard" })}
                    </span>
                    <span className="text-muted-foreground ml-1">/month</span>
                  </div>
                  {plan.extraDetail && <p className="text-sm text-muted-foreground mt-2">{plan.extraDetail}</p>}
                </CardHeader>
                <CardContent className="flex-grow">
                  <ul className="space-y-3">
                    {plan.features.map((feature) => (
                      <li key={feature.name} className="flex items-start">
                        {feature.included ? (
                          <Check className="h-5 w-5 text-primary shrink-0 mr-2" />
                        ) : (
                          <X className="h-5 w-5 text-muted-foreground shrink-0 mr-2" />
                        )}
                        <span className={!feature.included ? "text-muted-foreground" : undefined}>
                          {feature.name}
                          {feature.details && feature.included && (
                            <span className="block text-sm text-muted-foreground">{feature.details}</span>
                          )}
                        </span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button asChild className={`w-full ${plan.highlighted ? "bg-primary" : ""}`}>
                    <Link href={`/membership/${plan.id}`}>Select {plan.title}</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="yearly" className="mt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan) => (
              <Card
                key={plan.id}
                className={`flex flex-col ${plan.highlighted ? "border-primary shadow-lg relative" : ""}`}
              >
                {plan.highlighted && (
                  <div className="py-1 px-4 bg-primary text-primary-foreground text-center text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <CardHeader>
                  <CardTitle>{plan.title}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-4">
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-bold">
                        {formatPrice(plan.priceYearly, { notation: "standard" })}
                      </span>
                      <span className="text-muted-foreground ml-1">/year</span>
                    </div>
                    <p className="text-sm text-green-600 mt-1">
                      Save {formatPrice(plan.priceMonthly * 12 - plan.priceYearly, { notation: "standard" })} per year
                    </p>
                  </div>
                  {plan.extraDetail && <p className="text-sm text-muted-foreground mt-2">{plan.extraDetail}</p>}
                </CardHeader>
                <CardContent className="flex-grow">
                  <ul className="space-y-3">
                    {plan.features.map((feature) => (
                      <li key={feature.name} className="flex items-start">
                        {feature.included ? (
                          <Check className="h-5 w-5 text-primary shrink-0 mr-2" />
                        ) : (
                          <X className="h-5 w-5 text-muted-foreground shrink-0 mr-2" />
                        )}
                        <span className={!feature.included ? "text-muted-foreground" : undefined}>
                          {feature.name}
                          {feature.details && feature.included && (
                            <span className="block text-sm text-muted-foreground">{feature.details}</span>
                          )}
                        </span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button asChild className={`w-full ${plan.highlighted ? "bg-primary" : ""}`}>
                    <Link href={`/membership/${plan.id}/yearly`}>Select {plan.title} Plan</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <div className="space-y-8 mt-16">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold">Frequently Asked Questions</h2>
          <p className="mt-4 text-muted-foreground">
            Still have questions? Find answers to the most common questions about our membership plans.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">How quickly can I expect help to arrive?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                Our average response time is 15-30 minutes, depending on your location and current demand. Members
                receive priority service during high-volume periods.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Can I use the service if I'm not in my own vehicle?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                Yes! Our Basic and Premium plans cover you as an individual, regardless of which vehicle you're in. The
                Family plan covers all registered vehicles in your household.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">How many service calls can I make per year?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                Basic members get 4 service calls per year, Premium members get 6 service calls per year, and Family
                plan members get 8 service calls per year. Additional calls are available at discounted member rates.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Is there a waiting period after signing up?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                For immediate assistance, there's a 24-hour waiting period after signing up for a new membership. If you
                need assistance right now, you can request service at our standard non-member rates.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">What areas do you service?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                We provide coverage throughout all 50 states and Canada. Our network includes over 45,000 service
                providers nationwide to ensure you're always covered.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Can I cancel my membership anytime?</CardTitle>
            </CardHeader>
            <CardContent>
              <p>
                Yes, you can cancel your membership at any time. For annual memberships, we provide a prorated refund
                for the unused portion of your membership if you cancel within the first 6 months.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8">
          <Button asChild>
            <Link href="/contact">
              Have More Questions? Contact Us <ChevronRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
      <div className="mt-12 text-center">
        <Button asChild>
          <Link href="/membership/compare">
            Compare All Plans <ChevronRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  )
}

