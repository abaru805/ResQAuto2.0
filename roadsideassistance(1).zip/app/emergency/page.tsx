"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Loader2, Phone, CheckCircle } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { EmergencyTracker } from "@/components/emergency-tracker"
import { useRouter, useSearchParams } from "next/navigation"
import { useSession } from "next-auth/react"

export default function EmergencyPage() {
  // Auth state
  const { data: session, status } = useSession()
  const isAuthenticated = status === "authenticated"

  // Form state
  const [activeTab, setActiveTab] = useState("location")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [location, setLocation] = useState("")
  const [isLocating, setIsLocating] = useState(false)
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    service: "",
    vehicleMake: "",
    vehicleModel: "",
    description: "",
  })
  const [vehicleId, setVehicleId] = useState<string | null>(null)
  const [userVehicles, setUserVehicles] = useState<any[]>([])
  const [serviceSubmitted, setServiceSubmitted] = useState(false)
  const [serviceId, setServiceId] = useState("")

  const { toast } = useToast()
  const router = useRouter()
  const searchParams = useSearchParams()

  // Check for vehicle ID in query params
  useEffect(() => {
    const vehicleParam = searchParams.get("vehicle")
    if (vehicleParam) {
      setVehicleId(vehicleParam)
    }

    // If user is authenticated, pre-fill form data
    if (isAuthenticated && session?.user) {
      setFormData((prev) => ({
        ...prev,
        name: session.user?.name || "",
        phone: "", // Would normally come from user profile
      }))

      // Fetch user vehicles
      // This would normally be an API call
      setUserVehicles([
        {
          id: "v1",
          make: "Toyota",
          model: "Camry",
          year: 2019,
          licensePlate: "ABC-1234",
        },
        {
          id: "v2",
          make: "Honda",
          model: "CR-V",
          year: 2021,
          licensePlate: "XYZ-5678",
        },
      ])
    }
  }, [isAuthenticated, session, searchParams])

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Handle service selection
  const handleServiceChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      service: value,
    }))
  }

  // Handle location detection
  const handleLocationRequest = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Geolocation not supported",
        description: "Your browser does not support location services.",
        variant: "destructive",
      })
      return
    }

    setIsLocating(true)

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords
        setCoordinates({ lat: latitude, lng: longitude })

        try {
          // Reverse geocoding to get address
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
          )

          if (response.ok) {
            const data = await response.json()
            setLocation(data.display_name)
          } else {
            setLocation(`${latitude.toFixed(6)}, ${longitude.toFixed(6)}`)
          }
        } catch (error) {
          setLocation(`${latitude.toFixed(6)}, ${longitude.toFixed(6)}`)
        }

        setIsLocating(false)
      },
      (error) => {
        console.error("Geolocation error:", error)
        setIsLocating(false)

        let errorMessage = "Could not detect your location"
        switch (error.code) {
          case 1:
            errorMessage = "You denied permission to use your location"
            break
          case 2:
            errorMessage = "Your location is unavailable"
            break
          case 3:
            errorMessage = "Location request timed out"
            break
        }

        toast({
          title: "Location error",
          description: errorMessage,
          variant: "destructive",
        })
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 },
    )
  }

  // Handle vehicle selection
  const handleVehicleSelect = (id: string) => {
    const vehicle = userVehicles.find((v) => v.id === id)
    if (vehicle) {
      setVehicleId(id)
      setFormData((prev) => ({
        ...prev,
        vehicleMake: vehicle.make,
        vehicleModel: vehicle.model,
      }))
    }
  }

  // Handle tab change
  const handleTabChange = (value: string) => {
    // Validate first tab before allowing to proceed
    if (value === "details" && activeTab === "location") {
      if (!location || !formData.name || !formData.phone) {
        toast({
          title: "Please complete all fields",
          description: "Location, name and phone number are required.",
          variant: "destructive",
        })
        return
      }
    }

    setActiveTab(value)
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!location) {
      toast({
        title: "Location required",
        description: "Please enter your current location or use auto-detect.",
        variant: "destructive",
      })
      return
    }

    if (!formData.service) {
      toast({
        title: "Service required",
        description: "Please select the type of service you need.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate API call to request service
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Generate a random service ID
      const generatedServiceId = `SR${Math.floor(100000 + Math.random() * 900000)}`
      setServiceId(generatedServiceId)
      setServiceSubmitted(true)

      toast({
        title: "Help is on the way!",
        description: "A technician has been dispatched to your location. ETA: 15 minutes.",
      })
    } catch (error) {
      console.error("Service request error:", error)
      toast({
        title: "Service request failed",
        description: "We couldn't process your request. Please try again or call our emergency number.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container max-w-4xl py-12">
      <div className="text-center mb-8">
        <Badge variant="destructive" className="mb-2">
          Emergency Assistance
        </Badge>
        <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-2">Need Help Now?</h1>
        <p className="text-muted-foreground">
          Request immediate roadside assistance. Our technicians are available 24/7.
        </p>
      </div>

      {serviceSubmitted ? (
        <div className="space-y-6">
          <Card className="bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800">
            <CardHeader>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                <CardTitle className="text-green-800 dark:text-green-300">Service Request Confirmed</CardTitle>
              </div>
              <CardDescription className="text-green-700 dark:text-green-400">
                Your service request has been received and a technician is on the way.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">Service Request ID:</span>
                  <span>{serviceId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Service Type:</span>
                  <span>{formData.service}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Location:</span>
                  <span className="text-right max-w-[60%] truncate">{location}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <EmergencyTracker serviceId={serviceId} />

          <Card>
            <CardHeader>
              <CardTitle>Need immediate help?</CardTitle>
              <CardDescription>Call our emergency hotline for direct assistance</CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-destructive p-3 rounded-full">
                  <Phone className="h-6 w-6 text-destructive-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">1-800-ROADHELP</p>
                  <p className="text-sm text-muted-foreground">Available 24/7</p>
                </div>
              </div>
              <Button variant="outline" size="lg" asChild>
                <a href="tel:18007623435">Call Now</a>
              </Button>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="grid gap-8 grid-cols-1 lg:grid-cols-3 mb-8">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Request Service Online</CardTitle>
              <CardDescription>
                Fill out the form below and we'll dispatch a technician to your location ASAP.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={handleTabChange}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="location">Location</TabsTrigger>
                  <TabsTrigger value="details">Details</TabsTrigger>
                </TabsList>
                <TabsContent value="location" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="location">Your Current Location</Label>
                    <div className="flex gap-2">
                      <Input
                        id="location"
                        placeholder="Enter your location"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="flex-1"
                      />
                      <Button onClick={handleLocationRequest} type="button" variant="outline" disabled={isLocating}>
                        {isLocating ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Locating...
                          </>
                        ) : (
                          "Auto-Detect"
                        )}
                      </Button>
                    </div>
                    {coordinates && (
                      <div className="mt-4 aspect-video w-full h-[200px] rounded-md overflow-hidden bg-muted">
                        <iframe
                          className="w-full h-full border-0"
                          loading="lazy"
                          allowFullScreen
                          src={`https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=${coordinates.lat},${coordinates.lng}&zoom=16`}
                          title="Your location"
                        ></iframe>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Your Name</Label>
                      <Input
                        id="name"
                        name="name"
                        placeholder="Enter your full name"
                        value={formData.name}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        name="phone"
                        placeholder="Enter your phone number"
                        value={formData.phone}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button
                      onClick={() => handleTabChange("details")}
                      disabled={!location || !formData.name || !formData.phone}
                    >
                      Next: Service Details
                    </Button>
                  </div>
                </TabsContent>
                <TabsContent value="details" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="service">Service Needed</Label>
                    <Select value={formData.service} onValueChange={handleServiceChange}>
                      <SelectTrigger id="service">
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="flat-tire">Flat Tire Change</SelectItem>
                        <SelectItem value="battery">Battery Jump Start</SelectItem>
                        <SelectItem value="fuel">Fuel Delivery</SelectItem>
                        <SelectItem value="lockout">Lockout Assistance</SelectItem>
                        <SelectItem value="towing">Towing</SelectItem>
                        <SelectItem value="winching">Winching</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {isAuthenticated && userVehicles.length > 0 && (
                    <div className="space-y-2">
                      <Label>Select a Vehicle</Label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {userVehicles.map((vehicle) => (
                          <div
                            key={vehicle.id}
                            className={`border rounded-md p-3 cursor-pointer transition-colors ${
                              vehicleId === vehicle.id ? "border-primary bg-primary/5" : "hover:border-primary/50"
                            }`}
                            onClick={() => handleVehicleSelect(vehicle.id)}
                          >
                            <div className="font-medium">
                              {vehicle.year} {vehicle.make} {vehicle.model}
                            </div>
                            <div className="text-sm text-muted-foreground">{vehicle.licensePlate}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="vehicleMake">Vehicle Make</Label>
                      <Input
                        id="vehicleMake"
                        name="vehicleMake"
                        placeholder="e.g., Toyota"
                        value={formData.vehicleMake}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="vehicleModel">Vehicle Model</Label>
                      <Input
                        id="vehicleModel"
                        name="vehicleModel"
                        placeholder="e.g., Camry"
                        value={formData.vehicleModel}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Describe Your Situation</Label>
                    <Textarea
                      id="description"
                      name="description"
                      placeholder="Please provide details about your emergency situation"
                      rows={3}
                      value={formData.description}
                      onChange={handleInputChange}
                    />
                  </div>

                  <div className="flex gap-2 justify-between">
                    <Button type="button" variant="outline" onClick={() => setActiveTab("location")}>
                      Back
                    </Button>
                    <Button onClick={handleSubmit} disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        "Request Assistance Now"
                      )}
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className="bg-destructive text-destructive-foreground">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5" /> Call for Immediate Help
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">1-800-ROADHELP</p>
              <p className="text-sm mt-2">Our support team is available 24/7</p>
            </CardContent>
            <CardFooter>
              <Button
                variant="outline"
                className="w-full border-destructive-foreground/20 hover:bg-destructive-foreground/10 text-destructive-foreground"
                asChild
              >
                <a href="tel:18007623435">Call Now</a>
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>What to Expect</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal pl-5 space-y-2">
            <li>After submitting your request, you'll receive a confirmation via text message.</li>
            <li>A technician will be dispatched to your location with an estimated time of arrival.</li>
            <li>You'll receive real-time updates on your technician's location and ETA.</li>
            <li>
              The technician will resolve your issue on-site if possible, or arrange for towing to a nearby repair
              facility.
            </li>
            <li>After the service is complete, you'll receive a digital receipt and service summary.</li>
          </ol>
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-sm text-muted-foreground">
            If you have a membership, please ensure you're logged in to receive your benefits.
          </p>
          <Button variant="outline" asChild>
            <a href="/login">Login to Account</a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

