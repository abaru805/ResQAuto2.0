"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { VehicleCard } from "@/components/vehicle-card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Plus } from "lucide-react"

// Sample data - would normally come from an API
const initialVehicles = [
  {
    id: "v1",
    make: "Toyota",
    model: "Camry",
    year: 2019,
    licensePlate: "ABC-1234",
    color: "Silver",
    image: "/placeholder.svg?height=150&width=300",
  },
  {
    id: "v2",
    make: "Honda",
    model: "CR-V",
    year: 2021,
    licensePlate: "XYZ-5678",
    color: "Blue",
    image: "/placeholder.svg?height=150&width=300",
  },
]

// Generate years from 1990 to current year
const currentYear = new Date().getFullYear()
const years = Array.from({ length: currentYear - 1990 + 1 }, (_, i) => currentYear - i)

export default function VehiclesPage() {
  const [vehicles, setVehicles] = useState(initialVehicles)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newVehicle, setNewVehicle] = useState({
    make: "",
    model: "",
    year: currentYear,
    licensePlate: "",
    color: "",
  })
  const { toast } = useToast()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewVehicle((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleYearChange = (value: string) => {
    setNewVehicle((prev) => ({
      ...prev,
      year: Number.parseInt(value),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!newVehicle.make || !newVehicle.model || !newVehicle.licensePlate) {
      toast({
        title: "Missing information",
        description: "Please fill out all required fields.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // This would be an API call in a real app
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Add vehicle to state
      const vehicleId = `v${Date.now()}`
      const vehicleWithId = {
        ...newVehicle,
        id: vehicleId,
        image: "/placeholder.svg?height=150&width=300",
      }

      setVehicles((prev) => [...prev, vehicleWithId])

      // Reset form
      setNewVehicle({
        make: "",
        model: "",
        year: currentYear,
        licensePlate: "",
        color: "",
      })

      setIsDialogOpen(false)

      toast({
        title: "Vehicle added",
        description: "Your vehicle has been added successfully.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "We couldn't add your vehicle. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteVehicle = async (id: string) => {
    try {
      // This would be an API call in a real app
      await new Promise((resolve) => setTimeout(resolve, 500))

      setVehicles((prev) => prev.filter((vehicle) => vehicle.id !== id))

      toast({
        title: "Vehicle removed",
        description: "The vehicle has been removed from your account.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "We couldn't remove the vehicle. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Vehicles</h1>
          <p className="text-muted-foreground">Manage the vehicles associated with your account.</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 md:mt-0">
              <Plus className="h-4 w-4 mr-2" />
              Add Vehicle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add a New Vehicle</DialogTitle>
              <DialogDescription>Enter the details of your vehicle to add it to your account.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="make">Make</Label>
                    <Input
                      id="make"
                      name="make"
                      placeholder="e.g., Toyota"
                      value={newVehicle.make}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="model">Model</Label>
                    <Input
                      id="model"
                      name="model"
                      placeholder="e.g., Camry"
                      value={newVehicle.model}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="year">Year</Label>
                    <Select value={newVehicle.year.toString()} onValueChange={handleYearChange}>
                      <SelectTrigger id="year">
                        <SelectValue placeholder="Select year" />
                      </SelectTrigger>
                      <SelectContent>
                        {years.map((year) => (
                          <SelectItem key={year} value={year.toString()}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="color">Color</Label>
                    <Input
                      id="color"
                      name="color"
                      placeholder="e.g., Silver"
                      value={newVehicle.color}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="licensePlate">License Plate</Label>
                  <Input
                    id="licensePlate"
                    name="licensePlate"
                    placeholder="e.g., ABC-1234"
                    value={newVehicle.licensePlate}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    "Add Vehicle"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {vehicles.length === 0 ? (
        <Card className="text-center py-8">
          <CardContent>
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="rounded-full bg-muted p-6">
                <Plus className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-medium">No vehicles yet</h3>
              <p className="text-muted-foreground">You haven't added any vehicles to your account yet.</p>
              <Button onClick={() => setIsDialogOpen(true)}>Add Your First Vehicle</Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vehicles.map((vehicle) => (
            <VehicleCard key={vehicle.id} vehicle={vehicle} onDelete={() => handleDeleteVehicle(vehicle.id)} />
          ))}
        </div>
      )}

      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Vehicle Management Tips</CardTitle>
          <CardDescription>
            Managing your vehicles helps us provide better roadside assistance when you need it.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Keep your vehicle information up to date for faster service.</li>
            <li>Add all vehicles you regularly drive, even if you don't own them.</li>
            <li>If you sell or replace a vehicle, remember to update your account.</li>
            <li>When requesting assistance, we'll use this information to quickly identify your vehicle.</li>
          </ul>
        </CardContent>
        <CardFooter>
          <Button variant="outline" asChild>
            <a href="/faqs#vehicles" className="inline-flex items-center">
              Learn More
            </a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

