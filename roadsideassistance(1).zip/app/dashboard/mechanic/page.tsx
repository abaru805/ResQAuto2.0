"use client"

import { Input } from "@/components/ui/input"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Car, Clock, DollarSign, Star, CheckCircle, XCircle, MapPin, Phone } from "lucide-react"

// Sample data - this would normally come from your backend
const mechanicData = {
  name: "John Smith",
  email: "john.smith@example.com",
  phone: "(555) 123-4567",
  specialization: "Engine Specialist",
  rating: 4.8,
  totalJobs: 128,
  availabilityStatus: true,
  earnings: {
    today: 120,
    week: 850,
    month: 3200,
    pending: 450,
  },
  jobs: [
    {
      id: "j1",
      customerName: "Sarah Johnson",
      service: "Engine Repair",
      status: "In Progress",
      location: "123 Main St, Austin, TX",
      time: "Today, 2:30 PM",
      payment: 85,
      customerPhone: "(555) 987-6543",
    },
    {
      id: "j2",
      customerName: "Michael Chen",
      service: "Battery Replacement",
      status: "Pending",
      location: "456 Oak Ave, Austin, TX",
      time: "Today, 4:00 PM",
      payment: 65,
      customerPhone: "(555) 234-5678",
    },
    {
      id: "j3",
      customerName: "Emily Rodriguez",
      service: "Oil Change",
      status: "Completed",
      location: "789 Pine St, Austin, TX",
      time: "Yesterday, 11:00 AM",
      payment: 45,
      customerPhone: "(555) 345-6789",
    },
    {
      id: "j4",
      customerName: "David Wilson",
      service: "Brake Inspection",
      status: "Completed",
      location: "321 Elm St, Austin, TX",
      time: "Yesterday, 3:15 PM",
      payment: 55,
      customerPhone: "(555) 456-7890",
    },
  ],
  reviews: [
    {
      id: "r1",
      customerName: "Emily Rodriguez",
      rating: 5,
      comment: "John was very professional and fixed my oil leak quickly. Highly recommend!",
      date: "2 days ago",
    },
    {
      id: "r2",
      customerName: "David Wilson",
      rating: 4,
      comment: "Good service, arrived on time and did a thorough job with my brakes.",
      date: "1 week ago",
    },
    {
      id: "r3",
      customerName: "Lisa Thompson",
      rating: 5,
      comment: "Excellent service! John diagnosed and fixed my engine problem in no time.",
      date: "2 weeks ago",
    },
  ],
}

export default function MechanicDashboardPage() {
  const [availability, setAvailability] = useState(mechanicData.availabilityStatus)
  const { toast } = useToast()

  const handleAvailabilityChange = (checked: boolean) => {
    setAvailability(checked)
    toast({
      title: checked ? "You are now online" : "You are now offline",
      description: checked
        ? "You will now receive new job requests."
        : "You will not receive new job requests until you go online again.",
    })
  }

  const handleJobStatusChange = (jobId: string, newStatus: string) => {
    toast({
      title: "Job status updated",
      description: `Job #${jobId} has been marked as ${newStatus}.`,
    })
  }

  const handleWithdrawal = (method: string) => {
    toast({
      title: "Withdrawal requested",
      description: `Your withdrawal request via ${method} has been submitted.`,
    })
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Mechanic Dashboard</h1>
          <p className="text-muted-foreground">Manage your jobs, track earnings, and update your availability.</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Switch id="availability" checked={availability} onCheckedChange={handleAvailabilityChange} />
            <Label htmlFor="availability" className="font-medium">
              {availability ? "Online" : "Offline"}
            </Label>
          </div>
          <Badge variant={availability ? "default" : "outline"} className={availability ? "bg-green-500" : ""}>
            {availability ? "Available for Jobs" : "Unavailable"}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Earnings</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${mechanicData.earnings.today}</div>
            <p className="text-xs text-muted-foreground mt-1">
              From {mechanicData.jobs.filter((j) => j.status === "Completed" && j.time.includes("Today")).length}{" "}
              completed jobs
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Jobs</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mechanicData.totalJobs}</div>
            <p className="text-xs text-muted-foreground mt-1">Lifetime completed jobs</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rating</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mechanicData.rating} / 5</div>
            <div className="flex mt-1">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${i < Math.floor(mechanicData.rating) ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="jobs" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="jobs">Active Jobs</TabsTrigger>
          <TabsTrigger value="earnings">Earnings & Withdrawals</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
          <TabsTrigger value="profile">Profile</TabsTrigger>
        </TabsList>

        <TabsContent value="jobs">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-2xl font-bold">Your Jobs</h2>
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Jobs</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            {mechanicData.jobs.map((job) => (
              <Card key={job.id} className={job.status === "Completed" ? "opacity-75" : ""}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{job.service}</CardTitle>
                      <CardDescription>Customer: {job.customerName}</CardDescription>
                    </div>
                    <Badge
                      variant={
                        job.status === "Completed" ? "outline" : job.status === "In Progress" ? "default" : "secondary"
                      }
                      className={
                        job.status === "In Progress"
                          ? "bg-blue-500"
                          : job.status === "Completed"
                            ? "border-green-500 text-green-500"
                            : ""
                      }
                    >
                      {job.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                    <div className="flex items-start">
                      <MapPin className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground" />
                      <span>{job.location}</span>
                    </div>
                    <div className="flex items-start">
                      <Clock className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground" />
                      <span>{job.time}</span>
                    </div>
                    <div className="flex items-start">
                      <Phone className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground" />
                      <span>{job.customerPhone}</span>
                    </div>
                    <div className="flex items-start">
                      <DollarSign className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground" />
                      <span>${job.payment}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end space-x-2">
                  {job.status === "Pending" && (
                    <>
                      <Button variant="outline" size="sm" onClick={() => handleJobStatusChange(job.id, "Rejected")}>
                        <XCircle className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                      <Button size="sm" onClick={() => handleJobStatusChange(job.id, "Accepted")}>
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Accept
                      </Button>
                    </>
                  )}
                  {job.status === "In Progress" && (
                    <Button size="sm" onClick={() => handleJobStatusChange(job.id, "Completed")}>
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Mark as Completed
                    </Button>
                  )}
                  {job.status === "Completed" && (
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="earnings">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Earnings Summary</CardTitle>
                  <CardDescription>Overview of your earnings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-sm text-muted-foreground">Today</div>
                        <div className="text-2xl font-bold">${mechanicData.earnings.today}</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-sm text-muted-foreground">This Week</div>
                        <div className="text-2xl font-bold">${mechanicData.earnings.week}</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-sm text-muted-foreground">This Month</div>
                        <div className="text-2xl font-bold">${mechanicData.earnings.month}</div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-sm text-muted-foreground">Pending</div>
                        <div className="text-2xl font-bold">${mechanicData.earnings.pending}</div>
                      </CardContent>
                    </Card>
                  </div>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Recent Transactions</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-sm">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Engine Repair - Sarah Johnson</span>
                          </div>
                          <div className="font-medium">+$85.00</div>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Oil Change - Emily Rodriguez</span>
                          </div>
                          <div className="font-medium">+$45.00</div>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Brake Inspection - David Wilson</span>
                          </div>
                          <div className="font-medium">+$55.00</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Withdraw Earnings</CardTitle>
                  <CardDescription>
                    Available balance: ${mechanicData.earnings.month - mechanicData.earnings.pending}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Withdrawal Method</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bkash">bKash</SelectItem>
                        <SelectItem value="nagad">Nagad</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                        <SelectItem value="bank">Bank Transfer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Amount</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input className="pl-9" placeholder="0.00" />
                    </div>
                  </div>

                  <Button className="w-full" onClick={() => handleWithdrawal("bKash")}>
                    Request Withdrawal
                  </Button>

                  <div className="text-sm text-muted-foreground">
                    <p>Withdrawals are processed within 1-3 business days.</p>
                    <p>Minimum withdrawal amount: $50</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Withdrawal History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">$250.00</div>
                        <div className="text-sm text-muted-foreground">bKash - July 15, 2023</div>
                      </div>
                      <Badge variant="outline" className="text-green-500 border-green-500">
                        Completed
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">$180.00</div>
                        <div className="text-sm text-muted-foreground">PayPal - July 1, 2023</div>
                      </div>
                      <Badge variant="outline" className="text-green-500 border-green-500">
                        Completed
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">$320.00</div>
                        <div className="text-sm text-muted-foreground">Nagad - June 15, 2023</div>
                      </div>
                      <Badge variant="outline" className="text-green-500 border-green-500">
                        Completed
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="reviews">
          <div className="mb-4">
            <h2 className="text-2xl font-bold">Customer Reviews</h2>
            <p className="text-muted-foreground">See what customers are saying about your service.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <CardTitle>Overall Rating</CardTitle>
                  <div className="text-2xl font-bold">{mechanicData.rating}/5</div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-6 w-6 ${i < Math.floor(mechanicData.rating) ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`}
                    />
                  ))}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center">
                    <div className="w-12 text-sm">5 ★</div>
                    <div className="w-full bg-muted rounded-full h-2.5">
                      <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "70%" }}></div>
                    </div>
                    <div className="w-12 text-sm text-right">70%</div>
                  </div>
                  <div className="flex items-center">
                    <div className="w-12 text-sm">4 ★</div>
                    <div className="w-full bg-muted rounded-full h-2.5">
                      <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "20%" }}></div>
                    </div>
                    <div className="w-12 text-sm text-right">20%</div>
                  </div>
                  <div className="flex items-center">
                    <div className="w-12 text-sm">3 ★</div>
                    <div className="w-full bg-muted rounded-full h-2.5">
                      <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "7%" }}></div>
                    </div>
                    <div className="w-12 text-sm text-right">7%</div>
                  </div>
                  <div className="flex items-center">
                    <div className="w-12 text-sm">2 ★</div>
                    <div className="w-full bg-muted rounded-full h-2.5">
                      <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "2%" }}></div>
                    </div>
                    <div className="w-12 text-sm text-right">2%</div>
                  </div>
                  <div className="flex items-center">
                    <div className="w-12 text-sm">1 ★</div>
                    <div className="w-full bg-muted rounded-full h-2.5">
                      <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: "1%" }}></div>
                    </div>
                    <div className="w-12 text-sm text-right">1%</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Review Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Total Reviews</div>
                    <div className="text-2xl font-bold">87</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Last 30 Days</div>
                    <div className="text-2xl font-bold">12</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Positive</div>
                    <div className="text-2xl font-bold text-green-500">92%</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Negative</div>
                    <div className="text-2xl font-bold text-red-500">8%</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <h3 className="text-xl font-bold mt-8 mb-4">Recent Reviews</h3>
          <div className="space-y-4">
            {mechanicData.reviews.map((review) => (
              <Card key={review.id}>
                <CardContent className="pt-6">
                  <div className="flex justify-between mb-2">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10 mr-3">
                        <AvatarFallback>{review.customerName.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{review.customerName}</div>
                        <div className="text-sm text-muted-foreground">{review.date}</div>
                      </div>
                    </div>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${i < review.rating ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-sm">{review.comment}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="profile">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="md:col-span-1">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center space-y-4">
                  <Avatar className="h-24 w-24">
                    <AvatarFallback className="text-2xl">{mechanicData.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="space-y-1 text-center">
                    <h3 className="font-medium text-lg">{mechanicData.name}</h3>
                    <p className="text-sm text-muted-foreground">{mechanicData.specialization}</p>
                    <div className="flex justify-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${i < Math.floor(mechanicData.rating) ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"}`}
                        />
                      ))}
                      <span className="text-sm ml-1">{mechanicData.rating}</span>
                    </div>
                  </div>
                  <Button className="w-full">Edit Profile</Button>
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Full Name</div>
                    <div className="font-medium">{mechanicData.name}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Email</div>
                    <div className="font-medium">{mechanicData.email}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Phone</div>
                    <div className="font-medium">{mechanicData.phone}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm text-muted-foreground">Specialization</div>
                    <div className="font-medium">{mechanicData.specialization}</div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-2">Service Areas</h4>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline">Austin Central</Badge>
                    <Badge variant="outline">North Austin</Badge>
                    <Badge variant="outline">South Austin</Badge>
                    <Badge variant="outline">Round Rock</Badge>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-2">Services Offered</h4>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline">Engine Repair</Badge>
                    <Badge variant="outline">Oil Change</Badge>
                    <Badge variant="outline">Battery Replacement</Badge>
                    <Badge variant="outline">Brake Service</Badge>
                    <Badge variant="outline">Diagnostic</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline">Update Information</Button>
              </CardFooter>
            </Card>

            <Card className="md:col-span-3">
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Notification Preferences</h4>
                    <p className="text-sm text-muted-foreground">
                      Manage how you receive notifications about new jobs and updates.
                    </p>
                  </div>
                  <Button variant="outline">Manage</Button>
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div>
                    <h4 className="font-medium">Payment Methods</h4>
                    <p className="text-sm text-muted-foreground">Add or update your payment methods for withdrawals.</p>
                  </div>
                  <Button variant="outline">Manage</Button>
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div>
                    <h4 className="font-medium">Security Settings</h4>
                    <p className="text-sm text-muted-foreground">Update your password and security preferences.</p>
                  </div>
                  <Button variant="outline">Manage</Button>
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div>
                    <h4 className="font-medium text-destructive">Delete Account</h4>
                    <p className="text-sm text-muted-foreground">Permanently delete your account and all data.</p>
                  </div>
                  <Button variant="destructive">Delete Account</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

