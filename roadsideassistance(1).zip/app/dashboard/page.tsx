"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Calendar, Car, Info, ShieldCheck } from "lucide-react"
import { ServiceHistoryItem } from "@/components/service-history-item"
import { VehicleCard } from "@/components/vehicle-card"
import Link from "next/link"

// Sample data - this would normally come from your backend
const userData = {
  name: "Sarah Johnson",
  email: "sarah.johnson@example.com",
  phone: "(555) 123-4567",
  plan: "Premium",
  memberSince: "Jan 2022",
  remainingServices: 4,
  nextPayment: "Aug 15, 2023",
  vehicles: [
    {
      id: "v1",
      make: "Toyota",
      model: "Camry",
      year: 2019,
      licensePlate: "ABC-1234",
      color: "Silver",
      image: "/placeholder.svg?height=150&width=300",
    },
    {
      id: "v2",
      make: "Honda",
      model: "CR-V",
      year: 2021,
      licensePlate: "XYZ-5678",
      color: "Blue",
      image: "/placeholder.svg?height=150&width=300",
    },
  ],
  serviceHistory: [
    {
      id: "s1",
      date: "2023-07-15",
      type: "Flat Tire Change",
      location: "1234 Main St, Austin, TX",
      technician: "John Smith",
      status: "Completed",
      cost: "$0.00",
      notes: "Front passenger side tire replaced with spare.",
    },
    {
      id: "s2",
      date: "2023-05-22",
      type: "Battery Jump Start",
      location: "456 Park Ave, Austin, TX",
      technician: "Maria Garcia",
      status: "Completed",
      cost: "$0.00",
      notes: "Battery tested at 60% after jump start. Recommended replacement soon.",
    },
    {
      id: "s3",
      date: "2023-02-10",
      type: "Lockout Assistance",
      location: "789 Oak Dr, Austin, TX",
      technician: "David Chen",
      status: "Completed",
      cost: "$0.00",
      notes: "Vehicle unlocked successfully with no damage.",
    },
  ],
  currentService: {
    id: "current1",
    type: "Towing",
    requestedAt: "2023-08-02T10:15:00",
    status: "In Progress",
    location: "5678 Elm St, Austin, TX",
    destination: "ABC Auto Repair, 910 Mechanic Ave, Austin, TX",
    technician: {
      name: "Robert Johnson",
      rating: 4.9,
      photo: "/placeholder.svg?height=50&width=50",
    },
    eta: "10 minutes",
  },
}

export default function DashboardPage() {
  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back, {userData.name}</h1>
          <p className="text-muted-foreground">Manage your account, view service history, and request assistance.</p>
        </div>
        <Button asChild className="mt-4 md:mt-0" size="lg">
          <Link href="/emergency">Request Assistance</Link>
        </Button>
      </div>

      {userData.currentService && (
        <Alert className="mb-8 bg-yellow-50 border-yellow-200 dark:bg-yellow-950 dark:border-yellow-800">
          <Info className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
          <AlertTitle className="text-yellow-800 dark:text-yellow-300">Active Service in Progress</AlertTitle>
          <AlertDescription className="text-yellow-700 dark:text-yellow-400">
            You have a {userData.currentService.type} service in progress. Your technician is on the way with an ETA of{" "}
            {userData.currentService.eta}.
          </AlertDescription>
          <div className="mt-4">
            <Button
              asChild
              variant="outline"
              className="border-yellow-200 dark:border-yellow-800 hover:bg-yellow-100 dark:hover:bg-yellow-900"
            >
              <Link href="/current-service">View Details</Link>
            </Button>
          </div>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Membership Plan</CardTitle>
            <ShieldCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{userData.plan}</div>
              <Badge variant="outline">Active</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Member since {userData.memberSince}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Remaining Services</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userData.remainingServices} / 6</div>
            <p className="text-xs text-muted-foreground mt-1">Resets on your next billing date</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Payment</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userData.nextPayment}</div>
            <p className="text-xs text-muted-foreground mt-1">$19.99/month - Auto-renew enabled</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="vehicles" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="vehicles">My Vehicles</TabsTrigger>
          <TabsTrigger value="history">Service History</TabsTrigger>
          <TabsTrigger value="account">Account Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="vehicles">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-2xl font-bold">Registered Vehicles</h2>
            <Button asChild>
              <Link href="/dashboard/add-vehicle">Add Vehicle</Link>
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {userData.vehicles.map((vehicle) => (
              <VehicleCard key={vehicle.id} vehicle={vehicle} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="history">
          <div className="mb-4">
            <h2 className="text-2xl font-bold">Service History</h2>
            <p className="text-muted-foreground">View details of your past service requests.</p>
          </div>
          <div className="space-y-4">
            {userData.serviceHistory.map((service) => (
              <ServiceHistoryItem key={service.id} service={service} />
            ))}
          </div>
        </TabsContent>
        <TabsContent value="account">
          <div className="mb-4">
            <h2 className="text-2xl font-bold">Account Settings</h2>
            <p className="text-muted-foreground">Manage your personal information and subscription details.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>Manage your personal details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-sm font-medium">Name</div>
                  <div>{userData.name}</div>
                </div>
                <div>
                  <div className="text-sm font-medium">Email</div>
                  <div>{userData.email}</div>
                </div>
                <div>
                  <div className="text-sm font-medium">Phone</div>
                  <div>{userData.phone}</div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" asChild>
                  <Link href="/dashboard/edit-profile">Edit Profile</Link>
                </Button>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Membership Details</CardTitle>
                <CardDescription>Manage your subscription</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-sm font-medium">Current Plan</div>
                  <div>{userData.plan} ($19.99/month)</div>
                </div>
                <div>
                  <div className="text-sm font-medium">Billing Cycle</div>
                  <div>Monthly - Next payment on {userData.nextPayment}</div>
                </div>
                <div>
                  <div className="text-sm font-medium">Payment Method</div>
                  <div>Visa ending in 4242</div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href="/dashboard/payment-methods">Update Payment</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/dashboard/change-plan">Change Plan</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

