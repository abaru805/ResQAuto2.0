"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Loader2, Plus, Trash } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import type { SlideType } from "@/components/hero-slider"
import Image from "next/image"

export default function AdminSlidersPage() {
  const [slides, setSlides] = useState<SlideType[]>([
    {
      id: "1",
      imageUrl: "/placeholder.svg?height=600&width=1200",
      title: "24/7 Roadside Assistance",
      description: "We're here when you need us most. Our professional team is available around the clock.",
      buttonText: "Request Help Now",
      buttonLink: "/emergency",
      order: 1,
    },
    {
      id: "2",
      imageUrl: "/placeholder.svg?height=600&width=1200",
      title: "Join Our Premium Membership",
      description: "Get priority service, exclusive benefits, and peace of mind on every journey.",
      buttonText: "View Plans",
      buttonLink: "/membership",
      order: 2,
    },
    {
      id: "3",
      imageUrl: "/placeholder.svg?height=600&width=1200",
      title: "Professional Mechanics Network",
      description: "Our certified mechanics are ready to help you with any vehicle issue, anytime, anywhere.",
      buttonText: "Learn More",
      buttonLink: "/services",
      order: 3,
    },
  ])

  const [newSlide, setNewSlide] = useState<Omit<SlideType, "id">>({
    imageUrl: "",
    title: "",
    description: "",
    buttonText: "",
    buttonLink: "",
    order: slides.length + 1,
  })

  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleAddSlide = async () => {
    if (!newSlide.imageUrl || !newSlide.title || !newSlide.buttonLink) {
      toast({
        title: "Missing required fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // In a real app, this would be an API call to your backend
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const id = Date.now().toString()
      setSlides([...slides, { ...newSlide, id }])

      // Reset form
      setNewSlide({
        imageUrl: "",
        title: "",
        description: "",
        buttonText: "",
        buttonLink: "",
        order: slides.length + 2,
      })

      toast({
        title: "Slide added successfully",
        description: "The new slide has been added to the homepage slider",
      })
    } catch (error) {
      toast({
        title: "Error adding slide",
        description: "There was a problem adding the slide. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteSlide = async (id: string) => {
    setIsLoading(true)

    try {
      // In a real app, this would be an API call to your backend
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setSlides(slides.filter((slide) => slide.id !== id))

      toast({
        title: "Slide deleted successfully",
        description: "The slide has been removed from the homepage slider",
      })
    } catch (error) {
      toast({
        title: "Error deleting slide",
        description: "There was a problem deleting the slide. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleUpdateOrder = (id: string, newOrder: number) => {
    setSlides(
      slides
        .map((slide) => (slide.id === id ? { ...slide, order: newOrder } : slide))
        .sort((a, b) => a.order - b.order),
    )
  }

  return (
    <div className="container py-10">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Homepage Sliders</h1>
          <p className="text-muted-foreground">Manage the promotional sliders on the homepage</p>
        </div>
        <Button onClick={() => (window.location.href = "/admin")}>Back to Dashboard</Button>
      </div>

      <div className="grid gap-8 grid-cols-1 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Current Sliders</CardTitle>
              <CardDescription>These sliders are currently displayed on the homepage. Drag to reorder.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order</TableHead>
                    <TableHead>Image</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Button</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {slides.map((slide) => (
                    <TableRow key={slide.id}>
                      <TableCell>
                        <Input
                          type="number"
                          value={slide.order}
                          onChange={(e) => handleUpdateOrder(slide.id, Number.parseInt(e.target.value))}
                          className="w-16"
                          min={1}
                        />
                      </TableCell>
                      <TableCell>
                        <div className="relative w-20 h-12 rounded overflow-hidden">
                          <Image
                            src={slide.imageUrl || "/placeholder.svg"}
                            alt={slide.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{slide.title}</TableCell>
                      <TableCell>{slide.buttonText}</TableCell>
                      <TableCell>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteSlide(slide.id)}
                          disabled={isLoading}
                        >
                          <Trash className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Add New Slider</CardTitle>
              <CardDescription>Create a new promotional slider for the homepage</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="imageUrl">Image URL *</Label>
                  <Input
                    id="imageUrl"
                    value={newSlide.imageUrl}
                    onChange={(e) => setNewSlide({ ...newSlide, imageUrl: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                    required
                  />
                  <p className="text-xs text-muted-foreground">Recommended size: 1920x1080px</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    value={newSlide.title}
                    onChange={(e) => setNewSlide({ ...newSlide, title: e.target.value })}
                    placeholder="24/7 Roadside Assistance"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newSlide.description}
                    onChange={(e) => setNewSlide({ ...newSlide, description: e.target.value })}
                    placeholder="We're here when you need us most..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="buttonText">Button Text *</Label>
                  <Input
                    id="buttonText"
                    value={newSlide.buttonText}
                    onChange={(e) => setNewSlide({ ...newSlide, buttonText: e.target.value })}
                    placeholder="Request Help Now"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="buttonLink">Button Link *</Label>
                  <Input
                    id="buttonLink"
                    value={newSlide.buttonLink}
                    onChange={(e) => setNewSlide({ ...newSlide, buttonLink: e.target.value })}
                    placeholder="/emergency"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="order">Display Order</Label>
                  <Input
                    id="order"
                    type="number"
                    value={newSlide.order}
                    onChange={(e) => setNewSlide({ ...newSlide, order: Number.parseInt(e.target.value) })}
                    min={1}
                  />
                </div>
              </form>
            </CardContent>
            <CardFooter>
              <Button onClick={handleAddSlide} disabled={isLoading} className="w-full">
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Slider
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

