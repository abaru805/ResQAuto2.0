"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Plus, Trash, Calendar } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import type { AdType } from "@/components/ads-section"
import Image from "next/image"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"

export default function AdminAdsPage() {
  const [ads, setAds] = useState<AdType[]>([
    {
      id: "1",
      imageUrl: "/placeholder.svg?height=300&width=600",
      title: "Premium Membership Discount",
      description: "Get 20% off on our Premium membership plan for a limited time.",
      link: "/membership/premium",
      type: "promotion",
      startDate: "2023-01-01",
      endDate: "2023-12-31",
      isActive: true,
    },
    {
      id: "2",
      imageUrl: "/placeholder.svg?height=300&width=600",
      title: "John's Auto Repair",
      description: "Certified mechanic with 15+ years of experience. Available 24/7.",
      link: "/mechanics/johns-auto",
      type: "mechanic",
      startDate: "2023-01-01",
      endDate: "2023-12-31",
      isActive: true,
    },
    {
      id: "3",
      imageUrl: "/placeholder.svg?height=300&width=600",
      title: "Quick Towing Services",
      description: "Fast and reliable towing services for all vehicle types.",
      link: "/services/towing",
      type: "service",
      startDate: "2023-01-01",
      endDate: "2023-12-31",
      isActive: true,
    },
    {
      id: "4",
      imageUrl: "/placeholder.svg?height=300&width=600",
      title: "Auto Parts Discount",
      description: "Quality auto parts at discounted prices.",
      link: "https://example.com/auto-parts",
      type: "external",
      startDate: "2023-01-01",
      endDate: "2023-12-31",
      isActive: true,
    },
  ])

  const [newAd, setNewAd] = useState<Omit<AdType, "id">>({
    imageUrl: "",
    title: "",
    description: "",
    link: "",
    type: "promotion",
    startDate: format(new Date(), "yyyy-MM-dd"),
    endDate: format(new Date(new Date().setMonth(new Date().getMonth() + 1)), "yyyy-MM-dd"),
    isActive: true,
  })

  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleAddAd = async () => {
    if (!newAd.imageUrl || !newAd.title || !newAd.link) {
      toast({
        title: "Missing required fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // In a real app, this would be an API call to your backend
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const id = Date.now().toString()
      setAds([...ads, { ...newAd, id }])

      // Reset form
      setNewAd({
        imageUrl: "",
        title: "",
        description: "",
        link: "",
        type: "promotion",
        startDate: format(new Date(), "yyyy-MM-dd"),
        endDate: format(new Date(new Date().setMonth(new Date().getMonth() + 1)), "yyyy-MM-dd"),
        isActive: true,
      })

      toast({
        title: "Ad added successfully",
        description: "The new ad has been added to the system",
      })
    } catch (error) {
      toast({
        title: "Error adding ad",
        description: "There was a problem adding the ad. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteAd = async (id: string) => {
    setIsLoading(true)

    try {
      // In a real app, this would be an API call to your backend
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setAds(ads.filter((ad) => ad.id !== id))

      toast({
        title: "Ad deleted successfully",
        description: "The ad has been removed from the system",
      })
    } catch (error) {
      toast({
        title: "Error deleting ad",
        description: "There was a problem deleting the ad. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleActive = async (id: string) => {
    setAds(ads.map((ad) => (ad.id === id ? { ...ad, isActive: !ad.isActive } : ad)))
  }

  return (
    <div className="container py-10">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Ads Management</h1>
          <p className="text-muted-foreground">Manage promotional and advertising content</p>
        </div>
        <Button onClick={() => (window.location.href = "/admin")}>Back to Dashboard</Button>
      </div>

      <div className="grid gap-8 grid-cols-1 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Current Ads</CardTitle>
              <CardDescription>Manage all advertising content displayed on the platform</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Image</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Date Range</TableHead>
                    <TableHead>Active</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ads.map((ad) => (
                    <TableRow key={ad.id}>
                      <TableCell>
                        <div className="relative w-20 h-12 rounded overflow-hidden">
                          <Image src={ad.imageUrl || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{ad.title}</TableCell>
                      <TableCell>
                        <Badge type={ad.type} />
                      </TableCell>
                      <TableCell className="text-xs">
                        {format(new Date(ad.startDate), "MMM d, yyyy")} - {format(new Date(ad.endDate), "MMM d, yyyy")}
                      </TableCell>
                      <TableCell>
                        <Switch checked={ad.isActive} onCheckedChange={() => handleToggleActive(ad.id)} />
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteAd(ad.id)}
                          disabled={isLoading}
                        >
                          <Trash className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Add New Ad</CardTitle>
              <CardDescription>Create a new advertisement or promotion</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="imageUrl">Image URL *</Label>
                  <Input
                    id="imageUrl"
                    value={newAd.imageUrl}
                    onChange={(e) => setNewAd({ ...newAd, imageUrl: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                    required
                  />
                  <p className="text-xs text-muted-foreground">Recommended size: 600x300px</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    value={newAd.title}
                    onChange={(e) => setNewAd({ ...newAd, title: e.target.value })}
                    placeholder="Premium Membership Discount"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newAd.description}
                    onChange={(e) => setNewAd({ ...newAd, description: e.target.value })}
                    placeholder="Get 20% off on our Premium membership plan..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="link">Link URL *</Label>
                  <Input
                    id="link"
                    value={newAd.link}
                    onChange={(e) => setNewAd({ ...newAd, link: e.target.value })}
                    placeholder="/membership/premium"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Ad Type *</Label>
                  <Select
                    value={newAd.type}
                    onValueChange={(value) => setNewAd({ ...newAd, type: value as AdType["type"] })}
                  >
                    <SelectTrigger id="type">
                      <SelectValue placeholder="Select ad type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="promotion">Promotion</SelectItem>
                      <SelectItem value="mechanic">Mechanic</SelectItem>
                      <SelectItem value="service">Service</SelectItem>
                      <SelectItem value="external">External (Sponsored)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Date *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newAd.startDate && "text-muted-foreground",
                          )}
                        >
                          <Calendar className="mr-2 h-4 w-4" />
                          {newAd.startDate ? format(new Date(newAd.startDate), "PPP") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={new Date(newAd.startDate)}
                          onSelect={(date) =>
                            setNewAd({ ...newAd, startDate: format(date || new Date(), "yyyy-MM-dd") })
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label>End Date *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !newAd.endDate && "text-muted-foreground",
                          )}
                        >
                          <Calendar className="mr-2 h-4 w-4" />
                          {newAd.endDate ? format(new Date(newAd.endDate), "PPP") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={new Date(newAd.endDate)}
                          onSelect={(date) => setNewAd({ ...newAd, endDate: format(date || new Date(), "yyyy-MM-dd") })}
                          initialFocus
                          disabled={(date) => date < new Date(newAd.startDate)}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="isActive"
                    checked={newAd.isActive}
                    onCheckedChange={(checked) => setNewAd({ ...newAd, isActive: checked })}
                  />
                  <Label htmlFor="isActive">Active</Label>
                </div>
              </form>
            </CardContent>
            <CardFooter>
              <Button onClick={handleAddAd} disabled={isLoading} className="w-full">
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Advertisement
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

function Badge({ type }: { type: AdType["type"] }) {
  const getTypeStyles = () => {
    switch (type) {
      case "promotion":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "mechanic":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "service":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
      case "external":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeStyles()}`}>
      {type.charAt(0).toUpperCase() + type.slice(1)}
    </span>
  )
}

