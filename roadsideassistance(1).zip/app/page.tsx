import { Button } from "@/components/ui/button"
import { ChevronRight, MapPin, Shield, Truck, Wrench } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { ServiceCard } from "@/components/service-card"
import { TestimonialCard } from "@/components/testimonial-card"
import { MembershipCard } from "@/components/membership-card"
import { HowItWorks } from "@/components/how-it-works"
import { HeroSlider } from "@/components/hero-slider"
import { AdsSection } from "@/components/ads-section"
import { AppDownload } from "@/components/app-download"
import { LiveChat } from "@/components/live-chat"

// Sample data for the slider
const sliderData = [
  {
    id: "1",
    imageUrl: "/placeholder.svg?height=600&width=1200",
    title: "24/7 Roadside Assistance",
    description: "We're here when you need us most. Our professional team is available around the clock.",
    buttonText: "Request Help Now",
    buttonLink: "/emergency",
    order: 1,
  },
  {
    id: "2",
    imageUrl: "/placeholder.svg?height=600&width=1200",
    title: "Join Our Premium Membership",
    description: "Get priority service, exclusive benefits, and peace of mind on every journey.",
    buttonText: "View Plans",
    buttonLink: "/membership",
    order: 2,
  },
  {
    id: "3",
    imageUrl: "/placeholder.svg?height=600&width=1200",
    title: "Professional Mechanics Network",
    description: "Our certified mechanics are ready to help you with any vehicle issue, anytime, anywhere.",
    buttonText: "Learn More",
    buttonLink: "/services",
    order: 3,
  },
]

// Sample data for ads
const adsData = [
  {
    id: "1",
    imageUrl: "/placeholder.svg?height=300&width=600",
    title: "Premium Membership Discount",
    description: "Get 20% off on our Premium membership plan for a limited time.",
    link: "/membership/premium",
    type: "promotion",
    startDate: "2023-01-01",
    endDate: "2023-12-31",
    isActive: true,
  },
  {
    id: "2",
    imageUrl: "/placeholder.svg?height=300&width=600",
    title: "John's Auto Repair",
    description: "Certified mechanic with 15+ years of experience. Available 24/7.",
    link: "/mechanics/johns-auto",
    type: "mechanic",
    startDate: "2023-01-01",
    endDate: "2023-12-31",
    isActive: true,
  },
  {
    id: "3",
    imageUrl: "/placeholder.svg?height=300&width=600",
    title: "Quick Towing Services",
    description: "Fast and reliable towing services for all vehicle types.",
    link: "/services/towing",
    type: "service",
    startDate: "2023-01-01",
    endDate: "2023-12-31",
    isActive: true,
  },
  {
    id: "4",
    imageUrl: "/placeholder.svg?height=300&width=600",
    title: "Auto Parts Discount",
    description: "Quality auto parts at discounted prices.",
    link: "https://example.com/auto-parts",
    type: "external",
    startDate: "2023-01-01",
    endDate: "2023-12-31",
    isActive: true,
  },
]

export default function Home() {
  return (
    <div>
      {/* Hero Slider Section */}
      <HeroSlider slides={sliderData} />

      {/* Emergency Stats */}
      <section className="py-10 bg-destructive text-destructive-foreground">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div className="space-y-2">
              <p className="text-3xl font-bold">15 min</p>
              <p className="text-sm text-destructive-foreground/80">Average Response Time</p>
            </div>
            <div className="space-y-2">
              <p className="text-3xl font-bold">24/7</p>
              <p className="text-sm text-destructive-foreground/80">Service Availability</p>
            </div>
            <div className="space-y-2">
              <p className="text-3xl font-bold">98%</p>
              <p className="text-sm text-destructive-foreground/80">Customer Satisfaction</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Services</h2>
            <p className="mt-4 text-muted-foreground">
              We offer a complete range of roadside assistance services to get you back on the road quickly and safely.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ServiceCard
              icon={<Wrench className="w-10 h-10" />}
              title="Flat Tire Change"
              description="Quick replacement with your spare tire to get you back on the road."
              link="/services/flat-tire"
            />
            <ServiceCard
              icon={<Truck className="w-10 h-10" />}
              title="Battery Jump Start"
              description="Revive your dead battery and diagnose potential issues."
              link="/services/battery-jumpstart"
            />
            <ServiceCard
              icon={<MapPin className="w-10 h-10" />}
              title="Fuel Delivery"
              description="Emergency fuel delivered to your location when you run out."
              link="/services/fuel-delivery"
            />
            <ServiceCard
              icon={<Shield className="w-10 h-10" />}
              title="Lockout Assistance"
              description="Professional assistance when you're locked out of your vehicle."
              link="/services/lockout"
            />
            <ServiceCard
              icon={<Truck className="w-10 h-10" />}
              title="Towing Services"
              description="Safe transportation for your vehicle to a repair facility."
              link="/services/towing"
            />
            <ServiceCard
              icon={<Truck className="w-10 h-10" />}
              title="Winching"
              description="Recovery service to pull your vehicle from mud, snow, or other difficult terrain."
              link="/services/winching"
            />
          </div>
          <div className="mt-12 text-center">
            <Button asChild>
              <Link href="/services">
                View All Services <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Ads Section */}
      <AdsSection ads={adsData} />

      {/* How It Works */}
      <section className="py-16 bg-muted md:py-24">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How It Works</h2>
            <p className="mt-4 text-muted-foreground">Getting help is quick and easy when you need it most.</p>
          </div>
          <HowItWorks />
        </div>
      </section>

      {/* App Download Section */}
      <AppDownload />

      {/* Membership Plans */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Membership Plans</h2>
            <p className="mt-4 text-muted-foreground">
              Choose a membership plan that fits your needs and enjoy exclusive benefits and priority service.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <MembershipCard
              title="Basic"
              price={9.99}
              period="month"
              features={[
                "24/7 Roadside Assistance",
                "Flat Tire Assistance",
                "Battery Jump Start",
                "Lockout Service",
                "5 miles free towing",
                "Fuel Delivery (cost of fuel extra)",
              ]}
              link="/membership/basic"
              highlighted={false}
            />
            <MembershipCard
              title="Premium"
              price={19.99}
              period="month"
              features={[
                "Everything in Basic",
                "25 miles free towing",
                "Winching service",
                "Free fuel delivery",
                "Trip interruption benefits",
                "Rental car discounts",
              ]}
              link="/membership/premium"
              highlighted={true}
            />
            <MembershipCard
              title="Family"
              price={29.99}
              period="month"
              features={[
                "Everything in Premium",
                "Coverage for up to 4 vehicles",
                "50 miles free towing",
                "Extended trip interruption benefits",
                "Hotel discounts",
                "Identity theft protection",
              ]}
              link="/membership/family"
              highlighted={false}
            />
          </div>
          <div className="mt-12 text-center">
            <Button asChild>
              <Link href="/membership">
                Compare All Plans <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-muted md:py-24">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">What Our Customers Say</h2>
            <p className="mt-4 text-muted-foreground">
              Don't just take our word for it. See what our customers have to say about our services.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <TestimonialCard
              name="Sarah Johnson"
              location="Los Angeles, CA"
              rating={5}
              quote="I was stranded on the highway with a flat tire. RoadRescue arrived within 15 minutes and got me back on the road quickly. Excellent service!"
              image="/placeholder.svg?height=100&width=100"
            />
            <TestimonialCard
              name="Michael Chen"
              location="Seattle, WA"
              rating={5}
              quote="Their premium membership has saved me multiple times. The app makes it so easy to request help, and the technicians are always professional."
              image="/placeholder.svg?height=100&width=100"
            />
            <TestimonialCard
              name="Jessica Martinez"
              location="Miami, FL"
              rating={4}
              quote="When my battery died in a parking garage, I thought I was stuck for hours. RoadRescue came to the rescue within 20 minutes. Great service!"
              image="/placeholder.svg?height=100&width=100"
            />
          </div>
          <div className="mt-12 text-center">
            <Button asChild>
              <Link href="/testimonials">
                Read More Reviews <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="rounded-lg bg-primary text-primary-foreground p-8 md:p-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                  Ready for peace of mind on the road?
                </h2>
                <p className="mt-4">
                  Sign up today and get your first month of roadside assistance at 50% off. Drive with confidence
                  knowing we're just a call away.
                </p>
                <div className="mt-8 flex flex-col sm:flex-row gap-4">
                  <Button size="lg" variant="secondary" asChild>
                    <Link href="/register">Sign Up Now</Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    asChild
                    className="bg-transparent border-primary-foreground/20 hover:bg-primary-foreground/10"
                  >
                    <Link href="/contact">Contact Sales</Link>
                  </Button>
                </div>
              </div>
              <div className="hidden md:block">
                <Image
                  src="/placeholder.svg?height=400&width=500"
                  alt="Road Side Assistance"
                  width={500}
                  height={400}
                  className="rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Live Chat Component */}
      <LiveChat />
    </div>
  )
}

