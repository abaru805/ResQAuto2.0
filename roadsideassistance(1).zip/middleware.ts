import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { getToken } from "next-auth/jwt"

export async function middleware(request: NextRequest) {
  try {
    // Get the pathname from the request
    const path = request.nextUrl.pathname

    // Check if the path starts with /dashboard
    const isDashboardPath = path.startsWith("/dashboard")
    const isAuthPath = path === "/login" || path === "/register"

    // Get the token using next-auth/jwt helper
    const token = await getToken({
      req: request,
      secret: process.env.NEXTAUTH_SECRET,
    })

    const isAuthenticated = !!token

    // If accessing dashboard routes and not authenticated, redirect to login
    if (isDashboardPath && !isAuthenticated) {
      const loginUrl = new URL("/login", request.url)
      loginUrl.searchParams.set("callbackUrl", encodeURI(request.url))
      return NextResponse.redirect(loginUrl)
    }

    // If already logged in and trying to access login/register pages, redirect to dashboard
    if (isAuthPath && isAuthenticated) {
      const dashboardUrl = new URL("/dashboard", request.url)
      return NextResponse.redirect(dashboardUrl)
    }

    return NextResponse.next()
  } catch (error) {
    console.error("Middleware error:", error)
    return NextResponse.next()
  }
}

// Configure which paths the middleware runs on
export const config = {
  matcher: ["/dashboard/:path*", "/login", "/register"],
}

