"use client"

import * as React from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, User } from "lucide-react"
import { ModeToggle } from "@/components/mode-toggle"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { useSession, signOut } from "next-auth/react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const services = [
  {
    title: "Flat Tire Change",
    href: "/services/flat-tire",
    description: "Quick replacement with your spare tire to get you back on the road.",
  },
  {
    title: "Battery Jump Start",
    href: "/services/battery-jumpstart",
    description: "Revive your dead battery and diagnose potential issues.",
  },
  {
    title: "Fuel Delivery",
    href: "/services/fuel-delivery",
    description: "Emergency fuel delivered to your location when you run out.",
  },
  {
    title: "Lockout Assistance",
    href: "/services/lockout",
    description: "Professional assistance when you're locked out of your vehicle.",
  },
  {
    title: "Towing Services",
    href: "/services/towing",
    description: "Safe transportation for your vehicle to a repair facility.",
  },
  {
    title: "Winching",
    href: "/services/winching",
    description: "Recovery service to pull your vehicle from mud, snow, or other difficult terrain.",
  },
]

export function Navbar() {
  const pathname = usePathname()
  const { data: session, status } = useSession()
  const isLoading = status === "loading"
  const isAuthenticated = status === "authenticated"

  const handleSignOut = (e: React.MouseEvent) => {
    e.preventDefault()
    signOut({ callbackUrl: "/" })
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <Image src="/placeholder.svg?height=32&width=32" alt="RoadRescue Logo" width={32} height={32} />
            <span className="hidden font-bold sm:inline-block">RoadRescue</span>
          </Link>
          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Services</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                    {services.map((service) => (
                      <ListItem key={service.title} title={service.title} href={service.href}>
                        {service.description}
                      </ListItem>
                    ))}
                    <ListItem title="All Services" href="/services">
                      View our complete list of roadside assistance services.
                    </ListItem>
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/membership" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Membership</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/about" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>About Us</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/blog" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Blog</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/contact" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>Contact</NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <NavigationMenuTrigger>For Mechanics</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                    <ListItem title="Become a Mechanic" href="/mechanic/register">
                      Register as a mechanic and offer your services on our platform.
                    </ListItem>
                    <ListItem title="Mechanic Login" href="/mechanic/login">
                      Already registered? Log in to your mechanic account.
                    </ListItem>
                    <ListItem title="How It Works" href="/mechanic/how-it-works">
                      Learn how our platform connects mechanics with customers.
                    </ListItem>
                    <ListItem title="Mechanic FAQ" href="/mechanic/faq">
                      Find answers to common questions about being a mechanic on our platform.
                    </ListItem>
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>
        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="outline" size="icon" className="mr-2">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[300px] sm:w-[400px]">
            <nav className="flex flex-col gap-4">
              <Link
                href="/"
                className="flex items-center space-x-2"
                onClick={(e) => {
                  const el = document.querySelector("[data-radix-collection-item]")
                  el?.dispatchEvent(new Event("click", { bubbles: true }))
                }}
              >
                <Image src="/placeholder.svg?height=24&width=24" alt="RoadRescue Logo" width={24} height={24} />
                <span className="font-bold">RoadRescue</span>
              </Link>
              <Link href="/" className={cn("px-2 py-1 rounded-md", pathname === "/" ? "bg-muted" : "")}>
                Home
              </Link>
              <div className="px-2 py-1 font-medium">Services</div>
              <div className="pl-4 flex flex-col gap-2">
                {services.map((service) => (
                  <Link
                    key={service.title}
                    href={service.href}
                    className={cn("px-2 py-1 rounded-md text-sm", pathname === service.href ? "bg-muted" : "")}
                  >
                    {service.title}
                  </Link>
                ))}
                <Link
                  href="/services"
                  className={cn("px-2 py-1 rounded-md text-sm font-medium", pathname === "/services" ? "bg-muted" : "")}
                >
                  All Services
                </Link>
              </div>
              <Link
                href="/membership"
                className={cn("px-2 py-1 rounded-md", pathname === "/membership" ? "bg-muted" : "")}
              >
                Membership
              </Link>
              <Link href="/about" className={cn("px-2 py-1 rounded-md", pathname === "/about" ? "bg-muted" : "")}>
                About Us
              </Link>
              <Link href="/blog" className={cn("px-2 py-1 rounded-md", pathname === "/blog" ? "bg-muted" : "")}>
                Blog
              </Link>
              <Link href="/contact" className={cn("px-2 py-1 rounded-md", pathname === "/contact" ? "bg-muted" : "")}>
                Contact
              </Link>
              <Link
                href="/mechanic/register"
                className={cn("px-2 py-1 rounded-md", pathname === "/mechanic/register" ? "bg-muted" : "")}
              >
                Become a Mechanic
              </Link>
              {isAuthenticated ? (
                <>
                  <Link
                    href="/dashboard"
                    className={cn("px-2 py-1 rounded-md", pathname.startsWith("/dashboard") ? "bg-muted" : "")}
                  >
                    Dashboard
                  </Link>
                  <button
                    className="px-2 py-1 text-left rounded-md text-destructive hover:bg-muted"
                    onClick={handleSignOut}
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <Link href="/login" className={cn("px-2 py-1 rounded-md", pathname === "/login" ? "bg-muted" : "")}>
                    Login
                  </Link>
                  <Link
                    href="/register"
                    className={cn("px-2 py-1 rounded-md", pathname === "/register" ? "bg-muted" : "")}
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </nav>
          </SheetContent>
        </Sheet>
        <Link href="/" className="mr-6 flex items-center space-x-2 md:hidden">
          <Image src="/placeholder.svg?height=32&width=32" alt="RoadRescue Logo" width={32} height={32} />
          <span className="hidden font-bold sm:inline-block">RoadRescue</span>
        </Link>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <nav className="flex items-center space-x-2">
            {isLoading ? (
              <div className="h-8 w-20 bg-muted animate-pulse rounded-md"></div>
            ) : isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full" size="icon">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={session?.user?.image || ""} alt={session?.user?.name || ""} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {session?.user?.name?.charAt(0) || <User className="h-4 w-4" />}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <div className="flex flex-col space-y-1 p-2">
                    <p className="text-sm font-medium leading-none">{session?.user?.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">{session?.user?.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard">Dashboard</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard/profile">Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard/vehicles">My Vehicles</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard/history">Service History</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="cursor-pointer" onClick={handleSignOut}>
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button asChild variant="outline" className="hidden md:inline-flex">
                  <Link href="/login">Login</Link>
                </Button>
                <Button asChild className="hidden md:inline-flex">
                  <Link href="/register">Sign Up</Link>
                </Button>
              </>
            )}
            <Button asChild size="lg" className="bg-destructive hover:bg-destructive/90">
              <Link href="/emergency">Emergency Assistance</Link>
            </Button>
            <ModeToggle />
          </nav>
        </div>
      </div>
    </header>
  )
}

const ListItem = React.forwardRef<React.ElementRef<"a">, React.ComponentPropsWithoutRef<"a">>(
  ({ className, title, children, ...props }, ref) => {
    return (
      <li>
        <NavigationMenuLink asChild>
          <a
            ref={ref}
            className={cn(
              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
              className,
            )}
            {...props}
          >
            <div className="text-sm font-medium leading-none">{title}</div>
            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">{children}</p>
          </a>
        </NavigationMenuLink>
      </li>
    )
  },
)
ListItem.displayName = "ListItem"

