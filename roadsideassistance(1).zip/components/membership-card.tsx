import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import Link from "next/link"
// Format price locally instead of importing
function formatPrice(
  price: number,
  options: {
    currency?: "USD" | "EUR" | "GBP" | "BDT"
    notation?: Intl.NumberFormatOptions["notation"]
  } = {},
) {
  const { currency = "USD", notation = "compact" } = options

  const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    notation,
    maximumFractionDigits: 2,
  })

  return formatter.format(price)
}

interface MembershipCardProps {
  title: string
  price: number
  period: "month" | "year"
  features: string[]
  link: string
  highlighted?: boolean
}

export function MembershipCard({ title, price, period, features, link, highlighted = false }: MembershipCardProps) {
  return (
    <Card className={`h-full flex flex-col ${highlighted ? "border-primary shadow-lg" : ""}`}>
      {highlighted && (
        <div className="py-1 px-4 bg-primary text-primary-foreground text-center text-sm font-medium">Most Popular</div>
      )}
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>
          <div className="flex items-baseline mt-2">
            <span className="text-3xl font-bold">{formatPrice(price, { notation: "standard" })}</span>
            <span className="ml-1 text-muted-foreground">/{period}</span>
          </div>
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <ul className="space-y-2">
          {features.map((feature, i) => (
            <li key={i} className="flex items-start">
              <Check className="h-5 w-5 text-primary shrink-0 mr-2" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Button asChild className={`w-full ${highlighted ? "bg-primary" : ""}`}>
          <Link href={link}>Choose {title}</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

