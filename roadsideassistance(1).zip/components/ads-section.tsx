"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export interface AdType {
  id: string
  imageUrl: string
  title: string
  description: string
  link: string
  type: "mechanic" | "service" | "promotion" | "external"
  startDate: string
  endDate: string
  isActive: boolean
}

interface AdsSectionProps {
  ads: AdType[]
}

export function AdsSection({ ads }: AdsSectionProps) {
  const [activeAds, setActiveAds] = useState<AdType[]>([])

  useEffect(() => {
    // Filter active ads based on date and isActive flag
    const now = new Date()
    const filtered = ads.filter((ad) => {
      const startDate = new Date(ad.startDate)
      const endDate = new Date(ad.endDate)
      return ad.isActive && now >= startDate && now <= endDate
    })

    setActiveAds(filtered)
  }, [ads])

  if (!activeAds.length) {
    return null
  }

  const mechanicAds = activeAds.filter((ad) => ad.type === "mechanic")
  const serviceAds = activeAds.filter((ad) => ad.type === "service")
  const promotionAds = activeAds.filter((ad) => ad.type === "promotion")
  const externalAds = activeAds.filter((ad) => ad.type === "external")

  return (
    <section className="py-12 bg-muted/30">
      <div className="container">
        <h2 className="text-3xl font-bold text-center mb-8">Featured Promotions</h2>

        <Tabs defaultValue="all" className="w-full">
          <div className="flex justify-center mb-6">
            <TabsList>
              <TabsTrigger value="all">All Promotions</TabsTrigger>
              <TabsTrigger value="mechanics">Mechanics</TabsTrigger>
              <TabsTrigger value="services">Services</TabsTrigger>
              <TabsTrigger value="promotions">Special Offers</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="all">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activeAds.slice(0, 6).map((ad) => (
                <AdCard key={ad.id} ad={ad} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="mechanics">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mechanicAds.length > 0 ? (
                mechanicAds.map((ad) => <AdCard key={ad.id} ad={ad} />)
              ) : (
                <p className="col-span-full text-center text-muted-foreground py-8">
                  No mechanic promotions available at the moment.
                </p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="services">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {serviceAds.length > 0 ? (
                serviceAds.map((ad) => <AdCard key={ad.id} ad={ad} />)
              ) : (
                <p className="col-span-full text-center text-muted-foreground py-8">
                  No service promotions available at the moment.
                </p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="promotions">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {promotionAds.length > 0 ? (
                promotionAds.map((ad) => <AdCard key={ad.id} ad={ad} />)
              ) : (
                <p className="col-span-full text-center text-muted-foreground py-8">
                  No special offers available at the moment.
                </p>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {externalAds.length > 0 && (
          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
            {externalAds.slice(0, 2).map((ad) => (
              <div key={ad.id} className="relative overflow-hidden rounded-lg">
                <Link href={ad.link} target="_blank" rel="noopener noreferrer">
                  <div className="aspect-[21/9] relative">
                    <Image src={ad.imageUrl || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
                  </div>
                  <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                    Sponsored
                  </div>
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}

function AdCard({ ad }: { ad: AdType }) {
  return (
    <Card className="overflow-hidden h-full flex flex-col">
      <div className="relative aspect-video">
        <Image src={ad.imageUrl || "/placeholder.svg"} alt={ad.title} fill className="object-cover" />
        {ad.type === "external" && (
          <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">Sponsored</div>
        )}
      </div>
      <CardContent className="flex-grow flex flex-col p-4">
        <h3 className="font-bold text-lg mb-2">{ad.title}</h3>
        <p className="text-muted-foreground text-sm mb-4 flex-grow">{ad.description}</p>
        <Link
          href={ad.link}
          className="text-primary font-medium hover:underline"
          target={ad.type === "external" ? "_blank" : undefined}
          rel={ad.type === "external" ? "noopener noreferrer" : undefined}
        >
          Learn More
        </Link>
      </CardContent>
    </Card>
  )
}

