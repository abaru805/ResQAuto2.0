import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

export function AppDownload() {
  return (
    <section className="py-16 bg-gradient-to-r from-primary/10 to-primary/5">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl mb-4">Download Our Mobile App</h2>
              <p className="text-muted-foreground text-lg">
                Get roadside assistance at your fingertips. Our mobile app makes it easy to request help, track your
                technician, and manage your account.
              </p>
            </div>

            <ul className="space-y-3">
              <li className="flex items-start">
                <Check className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                <span>Request assistance with just a few taps</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                <span>Track your technician in real-time</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                <span>Manage your membership and payment details</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                <span>View your service history and upcoming appointments</span>
              </li>
              <li className="flex items-start">
                <Check className="h-5 w-5 text-primary shrink-0 mr-2 mt-0.5" />
                <span>Get exclusive app-only discounts and offers</span>
              </li>
            </ul>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button asChild className="h-auto py-2" variant="outline">
                <a href="#" target="_blank" rel="noopener noreferrer">
                  <div className="flex items-center">
                    <div className="mr-3">
                      <svg viewBox="0 0 24 24" className="h-8 w-8" fill="currentColor">
                        <path d="M17.9 19.9l.9-1.6c.1-.2 0-.4-.2-.5-1.1-.7-2-1.8-2.5-3.1-.5-1.3-.6-2.7-.2-4.1.4-1.3 1.1-2.5 2.2-3.3.2-.1.2-.4.1-.6l-.9-1.6c-.1-.2-.4-.2-.6-.1-1.7 1.2-3 3-3.6 5-.6 2-.5 4.1.4 6s2.4 3.5 4.3 4.5c.2.1.4 0 .5-.2zM12 16c0-2.2-1.8-4-4-4s-4 1.8-4 4 1.8 4 4 4 4-1.8 4-4zm-4 2c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zM15 4c-1.7 0-3 1.3-3 3s1.3 3 3 3 3-1.3 3-3-1.3-3-3-3zm0 4c-.6 0-1-.4-1-1s.4-1 1-1 1 .4 1 1-.4 1-1 1zM4 7c0 1.7 1.3 3 3 3s3-1.3 3-3-1.3-3-3-3-3 1.3-3 3zm4 0c0 .6-.4 1-1 1s-1-.4-1-1 .4-1 1-1 1 .4 1 1z" />
                      </svg>
                    </div>
                    <div className="text-left">
                      <div className="text-xs">GET IT ON</div>
                      <div className="text-base font-semibold">Google Play</div>
                    </div>
                  </div>
                </a>
              </Button>
              <Button asChild className="h-auto py-2" variant="outline">
                <a href="#" target="_blank" rel="noopener noreferrer">
                  <div className="flex items-center">
                    <div className="mr-3">
                      <svg viewBox="0 0 24 24" className="h-8 w-8" fill="currentColor">
                        <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
                      </svg>
                    </div>
                    <div className="text-left">
                      <div className="text-xs">Download on the</div>
                      <div className="text-base font-semibold">App Store</div>
                    </div>
                  </div>
                </a>
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="relative h-[500px] md:h-[600px] mx-auto max-w-[300px]">
              <Image
                src="/placeholder.svg?height=600&width=300"
                alt="RoadRescue Mobile App"
                fill
                className="object-contain"
              />
            </div>

            {/* Mini banners */}
            <div className="absolute top-1/4 -left-4 bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg transform -rotate-6 z-10 max-w-[180px] hidden md:block">
              <p className="text-sm font-bold">Track your technician in real-time!</p>
              <div className="h-2 w-24 bg-primary/20 rounded-full mt-2"></div>
              <div className="h-2 w-16 bg-primary/20 rounded-full mt-1"></div>
            </div>

            <div className="absolute bottom-1/4 -right-4 bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg transform rotate-6 z-10 max-w-[180px] hidden md:block">
              <p className="text-sm font-bold">Request help with just one tap!</p>
              <div className="h-2 w-24 bg-primary/20 rounded-full mt-2"></div>
              <div className="h-2 w-16 bg-primary/20 rounded-full mt-1"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

