"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Clock, MapPin, Phone, MessageSquare, Star } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import Link from "next/link"

interface TrackerProps {
  serviceId: string
  showMap?: boolean
}

interface TechnicianInfo {
  id: string
  name: string
  rating: number
  photo: string
  phone: string
  arrivalTime: string
  location: {
    latitude: number
    longitude: number
  }
  distanceAway: number
  eta: number
}

// This would normally come from an API or real-time service
const fetchTechnicianData = async (serviceId: string): Promise<TechnicianInfo> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return {
    id: "tech123",
    name: "Robert Johnson",
    rating: 4.9,
    photo: "/placeholder.svg?height=50&width=50",
    phone: "(555) 123-4567",
    arrivalTime: "10:45 AM",
    location: {
      latitude: 30.2672,
      longitude: -97.7431,
    },
    distanceAway: 3.2,
    eta: 8,
  }
}

export function EmergencyTracker({ serviceId, showMap = true }: TrackerProps) {
  const [loading, setLoading] = useState(true)
  const [technician, setTechnician] = useState<TechnicianInfo | null>(null)
  const [progress, setProgress] = useState(0)
  const { toast } = useToast()

  // Fetch technician data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchTechnicianData(serviceId)
        setTechnician(data)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching technician data:", error)
        toast({
          title: "Error",
          description: "Could not load technician information. Please try again.",
          variant: "destructive",
        })
      }
    }

    fetchData()
  }, [serviceId, toast])

  // Simulate progress updates
  useEffect(() => {
    if (!loading && technician) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval)
            toast({
              title: "Technician has arrived!",
              description: `${technician.name} has arrived at your location.`,
            })
            return 100
          }
          return prev + 5
        })
      }, 3000)

      return () => clearInterval(interval)
    }
  }, [loading, technician, toast])

  // Status text based on progress
  const getStatusText = () => {
    if (progress < 25) return "Technician is preparing and heading your way"
    if (progress < 50) return "Technician is en route to your location"
    if (progress < 75) return "Technician is getting close"
    if (progress < 100) return "Technician is almost there"
    return "Technician has arrived"
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="animate-pulse bg-muted h-6 w-3/4 rounded-md mb-2"></CardTitle>
          <CardDescription className="animate-pulse bg-muted h-4 w-1/2 rounded-md"></CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="animate-pulse bg-muted h-12 w-12 rounded-full"></div>
            <div className="space-y-2">
              <div className="animate-pulse bg-muted h-4 w-32 rounded-md"></div>
              <div className="animate-pulse bg-muted h-3 w-20 rounded-md"></div>
            </div>
          </div>
          <div className="animate-pulse bg-muted h-40 w-full rounded-md"></div>
        </CardContent>
      </Card>
    )
  }

  if (!technician) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Error Loading Tracker</CardTitle>
          <CardDescription>We couldn't load your service information. Please try again.</CardDescription>
        </CardHeader>
        <CardFooter>
          <Button onClick={() => window.location.reload()}>Retry</Button>
        </CardFooter>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Tracking Your Assistance</CardTitle>
            <CardDescription>Service ID: {serviceId}</CardDescription>
          </div>
          <Badge
            variant={progress === 100 ? "default" : "outline"}
            className={progress === 100 ? "bg-green-500 hover:bg-green-500/80" : ""}
          >
            {progress === 100 ? "Arrived" : "En Route"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="h-12 w-12">
              <AvatarImage src={technician.photo} alt={technician.name} />
              <AvatarFallback>RJ</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{technician.name}</p>
              <div className="flex items-center text-sm text-muted-foreground">
                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400 mr-1" />
                <span>{technician.rating} • Roadside Specialist</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="icon" variant="outline" asChild>
              <a href={`tel:${technician.phone}`}>
                <Phone className="h-4 w-4" />
                <span className="sr-only">Call technician</span>
              </a>
            </Button>
            <Button size="icon" variant="outline" asChild>
              <Link href={`/messages/${technician.id}`}>
                <MessageSquare className="h-4 w-4" />
                <span className="sr-only">Message technician</span>
              </Link>
            </Button>
          </div>
        </div>

        {showMap && (
          <div className="aspect-video relative rounded-md overflow-hidden bg-muted">
            <iframe
              className="absolute inset-0 w-full h-full border-0"
              loading="lazy"
              allowFullScreen
              src={`https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=${technician.location.latitude},${technician.location.longitude}&zoom=15`}
              title="Service location map"
            ></iframe>
            <div className="absolute bottom-3 left-3 right-3 bg-background/90 backdrop-blur-sm rounded-md p-3 shadow-md">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 text-destructive mr-2" />
                  <span className="text-sm font-medium">Technician location</span>
                </div>
                <Badge variant="outline" className="text-xs">
                  {technician.distanceAway} miles away
                </Badge>
              </div>
              <Progress value={progress} className="h-2" />
              <div className="flex items-center justify-between mt-2 text-sm">
                <div className="flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>ETA: {technician.eta} min</span>
                </div>
                <span className="text-xs text-muted-foreground">{getStatusText()}</span>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-1">
          <p className="text-sm font-medium">Service Details</p>
          <p className="text-sm text-muted-foreground">Expected arrival: {technician.arrivalTime}</p>
          <p className="text-sm text-muted-foreground">
            Your technician is bringing the necessary equipment for your service request.
          </p>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" asChild>
          <Link href="/emergency">View Service Details</Link>
        </Button>
        <Button variant="destructive" asChild>
          <Link href="/emergency/cancel">Cancel Service</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

