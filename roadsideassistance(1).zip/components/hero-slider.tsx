"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

export interface SlideType {
  id: string
  imageUrl: string
  title: string
  description: string
  buttonText: string
  buttonLink: string
  order: number
}

interface HeroSliderProps {
  slides: SlideType[]
  autoPlayInterval?: number
}

export function HeroSlider({ slides, autoPlayInterval = 5000 }: HeroSliderProps) {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null)
  const sortedSlides = [...slides].sort((a, b) => a.order - b.order)

  const goToSlide = (index: number) => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentSlide(index)
    setTimeout(() => setIsAnimating(false), 500) // Match this with the CSS transition time
  }

  const goToNextSlide = () => {
    const nextSlide = (currentSlide + 1) % sortedSlides.length
    goToSlide(nextSlide)
  }

  const goToPrevSlide = () => {
    const prevSlide = (currentSlide - 1 + sortedSlides.length) % sortedSlides.length
    goToSlide(prevSlide)
  }

  // Set up autoplay
  useEffect(() => {
    if (autoPlayInterval > 0) {
      autoPlayRef.current = setInterval(goToNextSlide, autoPlayInterval)
    }

    return () => {
      if (autoPlayRef.current) {
        clearInterval(autoPlayRef.current)
      }
    }
  }, [currentSlide, autoPlayInterval])

  // Pause autoplay on hover
  const pauseAutoPlay = () => {
    if (autoPlayRef.current) {
      clearInterval(autoPlayRef.current)
    }
  }

  // Resume autoplay on mouse leave
  const resumeAutoPlay = () => {
    if (autoPlayInterval > 0) {
      autoPlayRef.current = setInterval(goToNextSlide, autoPlayInterval)
    }
  }

  if (!sortedSlides.length) {
    return null
  }

  return (
    <div
      className="relative w-full h-[500px] md:h-[600px] overflow-hidden"
      onMouseEnter={pauseAutoPlay}
      onMouseLeave={resumeAutoPlay}
    >
      {/* Slides */}
      {sortedSlides.map((slide, index) => (
        <div
          key={slide.id}
          className={cn(
            "absolute inset-0 w-full h-full transition-all duration-500 ease-in-out transform",
            index === currentSlide
              ? "opacity-100 translate-x-0 z-10"
              : index < currentSlide
                ? "opacity-0 -translate-x-full z-0"
                : "opacity-0 translate-x-full z-0",
          )}
        >
          {/* Image with overlay */}
          <div className="absolute inset-0 bg-black/40 z-10" />
          <Image
            src={slide.imageUrl || "/placeholder.svg"}
            alt={slide.title}
            fill
            className="object-cover"
            priority={index === 0}
          />

          {/* Content */}
          <div className="relative z-20 container h-full flex flex-col justify-center items-start text-white">
            <h2
              className={cn(
                "text-3xl md:text-5xl font-bold mb-4 max-w-2xl transition-all duration-700 transform",
                index === currentSlide ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10",
              )}
              style={{ transitionDelay: "200ms" }}
            >
              {slide.title}
            </h2>
            <p
              className={cn(
                "text-lg md:text-xl mb-6 max-w-xl transition-all duration-700 transform",
                index === currentSlide ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10",
              )}
              style={{ transitionDelay: "400ms" }}
            >
              {slide.description}
            </p>
            <Button
              asChild
              size="lg"
              className={cn(
                "transition-all duration-700 transform",
                index === currentSlide ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10",
              )}
              style={{ transitionDelay: "600ms" }}
            >
              <Link href={slide.buttonLink}>{slide.buttonText}</Link>
            </Button>
          </div>
        </div>
      ))}

      {/* Navigation Arrows */}
      <button
        onClick={goToPrevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full transition-all"
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-6 w-6" />
      </button>
      <button
        onClick={goToNextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full transition-all"
        aria-label="Next slide"
      >
        <ChevronRight className="h-6 w-6" />
      </button>

      {/* Dots Navigation */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex space-x-2">
        {sortedSlides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={cn(
              "w-3 h-3 rounded-full transition-all",
              index === currentSlide ? "bg-white scale-125" : "bg-white/50 hover:bg-white/80",
            )}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}

