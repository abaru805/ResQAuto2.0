import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { ChevronRight } from "lucide-react"
import Link from "next/link"

interface ServiceCardProps {
  icon: React.ReactNode
  title: string
  description: string
  link: string
}

export function ServiceCard({ icon, title, description, link }: ServiceCardProps) {
  return (
    <Card>
      <CardHeader>
        <div className="p-2 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4">
          {icon}
        </div>
        <h3 className="text-xl font-bold">{title}</h3>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row gap-2 w-full">
        <Button asChild variant="outline" className="w-full sm:w-auto">
          <Link href={link}>
            Learn More <ChevronRight className="ml-1 h-4 w-4" />
          </Link>
        </Button>
        <Button asChild className="w-full sm:w-auto">
          <Link href={`/services/book?service=${encodeURIComponent(title)}`}>Book Now</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

